clear
syms alpha lambda p
load fundamentals.mat

% type contains different types of agents as described in the paper
% (Good at topic 1? Good at topic 2? First idea in topic 1 good? Second idea in topic 1 good? First idea in topic 2 good? Second idea in topic 2 good?)
% focus contains probabilities  that an agent of that type behaves in a
% described way times 6 (see Table 1 in the paper)
% ( Prob to focus on Topic 1 if not paid for focusing; Prob to focus on Topic 2 if not
% paid for focusing; not focusing if not paid for focusing; prob to focus
% on Topic 1 if paid for focusing; prob to focus on Topic 2 if not paid for
% focusing; not focusing if paid for focusing)

pgood1=alpha.^(1-types(:,1))*p;
pgood2=alpha.^(1-types(:,2))*p;
probs=(lambda.^(sum(types(:,1:2)')')).*((1-lambda).^((2-sum(types(:,1:2)'))')).*(pgood1.^(sum(types(:,3:4)')')).*(1-pgood1).^(2-sum(types(:,3:4)')').*(pgood2.^(sum(types(:,5:6)')')).*(1-pgood2).^(2-sum(types(:,5:6)')');

% probs provide probabilities, as a function of alpha, p, and lambda, of
% different types

simplify(sum(probs)) % should return 1

assume( p>0 & p<1 & alpha>0 & alpha<1 & lambda>0 & lambda<1) % so that our formulas make sense
%---------------------------------------------------------------
% If we don't reward focusing, who's better, those who focus or those who
% don't? Let us compare the chance that those who focus on something are good at
% something (not necessarily the same topic) with the chance that those who
% don't  focus are good at something 
PGoodAtSF=sum(probs.*(types(:,1)+types(:,2)>0).*(focus(:,1)+focus(:,2)))/sum(probs.*(focus(:,1)+focus(:,2)));
%this is probability of being good at something when focusing
PGoodAtSN=sum(probs.*(types(:,1)+types(:,2)>0).*focus(:,3))/sum(probs.*focus(:,3));
%this is probability of being good at something when not focusing

% Now, to eastablish Result 1. If we wanted to look at the difference between the two, we'd do
%d1=simplify(PGoodAtSF-PGoodAtSN);
% but this would contain a positive denominator that would not affect the outcome 
% but would clutter Matlab's sybmolic engine. Instead, we're looking at
% the numerator of the difference
d1=sum(probs.*(types(:,1)+types(:,2)>0).*(focus(:,1)+focus(:,2)))*sum(probs.*focus(:,3))-sum(probs.*(types(:,1)+types(:,2)>0).*focus(:,3))*sum(probs.*(focus(:,1)+focus(:,2)))
% you can see that it's a polynom
simplify(d1)
% you can see that under our assumptions on alpha, p, and lambda, this
% equation is always positive

% If we DO reward focusing, who's better, those who focus or those who
% don't? Let us compare the chance that those who focus on something are good at
% something (not necessarily the same topic) with the chance that those who
% don't  focus are good at something 
PGoodAtSF=sum(probs.*(types(:,4)+types(:,5)>0).*(focus(:,4)+focus(:,5)))/sum(probs.*(focus(:,4)+focus(:,5)));
PGoodAtSN=sum(probs.*(types(:,4)+types(:,5)>0).*focus(:,6))/sum(probs.*focus(:,6));

%For Result 2, again, we'd look at the sign of difference, like
%d2=simplify(PGoodAtSF-PGoodAtSN);
%but we look at denominator only
d2=sum(probs.*(types(:,1)+types(:,2)>0).*(focus(:,4)+focus(:,5)))*sum(probs.*focus(:,6))-sum(probs.*(types(:,1)+types(:,2)>0).*focus(:,6))*sum(probs.*(focus(:,4)+focus(:,5)));


d3=sum(probs.*(types(:,1)+types(:,2)>0).*(focus(:,1)+focus(:,2))).*sum(probs.*(focus(:,3)))-sum(probs.*(types(:,1)+types(:,2)>0).*(focus(:,3)))*sum(probs.*(focus(:,1)+focus(:,2)));

d4=sum(probs.*types(:,4).*focus(:,4)).*sum(probs.*(focus(:,6)))-sum(probs.*types(:,4).*(focus(:,6)))*sum(probs.*(focus(:,4)));