function q=AmountInRows(All);

q=(max(abs(All')))';
%q(find(q==0))=1;