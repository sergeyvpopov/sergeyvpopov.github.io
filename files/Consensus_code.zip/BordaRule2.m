%Borda Rule2 based on M Regenwetter and Rykhlevskaya 2007
%input matrix binary relations All (example wo1998)
%output list of candidates ranks, Max sum among candidates, winner (number)
function [v,MaxSum,WinnerCandidate]=BordaRule2(All,k);
if nargin<2;
    k=[];
end;
n=(sqrt(1+size(All,2)*4)+1)/2; % getting amount of candidates from All matrix
qtemp=AmountInRows(All);
%counting votes for particular candidate in pairwise elections
temp=(n-size(k,2)-ToGeneralizedRankMatrix(All,k)).*kron(ones(1,n), qtemp);
nanpos=isnan(temp(:,1));
nanpos=find(nanpos==0);
v=temp(nanpos,:);
if size(v,1)>1;
    v=sum(v);
 end;
[MaxSum,WinnerCandidate]=max(v);
v=VotesToRankings(-v, 1:n);
v(k)=ones(size(v(k)))*(n+1);
% values in scores can be negative, b/c total sum of margine difference is equal
% to zero, winner is the candidate who get highest number of votes
