function rep=CoombsOrder(All)
n=(sqrt(1+size(All,2)*4)+1)/2; % getting amount of candidates from All matrix

qtemp=AmountInRows(All);
plur=qtemp'*(ToGeneralizedRankMatrix(All)==1);
if sum(plur)==0;
    rep=zeros(1,n);
    return;
end;

orders=[];
for i=1:n;
    orders=[orders;Coombs(All,i)];
    if sum((orders(i,:)-zeros(1,n)).^2)==0;
        rep=zeros(1,n);
        return;
    end;
    
    if i>=2;
        orders(i,(find(orders(i-1,:)==1)))=-1;
    end;
    [~,winner]=max(orders(i,:));
    orders(i,winner)=-1;
    orders(i,(find(orders(i,:)>=0)))=0;
    orders(i,:)=-orders(i,:);
end;
orders=sum(orders);
rep=1+max(orders)-orders;

if sum(isnan(rep))>0;
    rep=zeros(1,n);
end;

if max(abs(sort(rep)-(1:n)))>0;
    rep=zeros(1,n);
end;