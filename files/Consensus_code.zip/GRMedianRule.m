function order=GRMedianRule(All);
% concept of GR from Regenwetter, M., and Rykhlevskaia, E. (2007)
n=(sqrt(1+size(All,2)*4)+1)/2;
tempall=ToGeneralizedRankMatrix(deaggregate(All));
order=VotesToRankings(median(tempall),(1:n)');
