function order=GRModeRule(All);
% concept of GR from Regenwetter, M., and Rykhlevskaia, E. (2007)
n=(sqrt(1+size(All,2)*4)+1)/2;
order=zeros(1,n);
tempall=ToGeneralizedRankMatrix(All);
for i=1:n;
    agg=summarizeBallots(tempall(:,i));
    freqs=agg(:,2);
    agg=agg(:,1);%./freqs;
    [x1,x2]=max(freqs);
    if size(find(freqs==x1),1)>1;
        order=zeros(1,n);
        return;
    end;
    order(i)=agg(x2);
end;
order=VotesToRankings(order,(1:n)',0);