% original matrix of original dataset for N candidate APA format [1 2 3 0 4 12; ...] N+1 column first N candidates 
%(so for example (0 1 0 0 2 12),means  ) pars=parameters df(5-1) for prob for 5 candidates
% + df(5!-1) prob for linear order of 5 candidates = 123 parameters. 
% datasets are in OriginalAPAData_agregFormat.mat
function [tot,lglk]=LogLikelihood(original,pars)
[m,n]=size(original);
n=n-1;
lglk=zeros(m,1);
F=prod(1:n);
%disp([m,n,F,size(pars)]);
par1=[pars(1:(F-1))]/max(1,sum(pars(1:(F-1))));
par1=[par1;1-sum(par1)];
%par1=[par1;pars(F:(F+n-2))];
par1=[par1;[pars(F:(F+n-2))]/max(sum(pars(F:(F+n-2))),1)];
par1=[par1;1-sum(pars(F:(F+n-2)))];
mpl=MakePermutationsOfLinear(1:n);
for i=1:m;
   criterion=(mpl(:,1)==original(i,1)|original(i,1)==0);
   for j=2:n;
       criterion=criterion.*(mpl(:,j)==original(i,j)|original(i,j)==0);
   end;
   pos=find(criterion);
   lglk(i)=log(par1(F+max(original(i,1:n))))+log(sum(par1(pos)));
end;
penalty=@(x,q) sum((x-q).^2.*(x<q)+1000*x.^2.*(x<0));
tot=sum(lglk.*original(:,(n+1)))-10000*F*penalty(par1(1:F),0.01/F);