% Malority Rule
% 
% input - matrix wo2000, output - raw of order, column - candidate (a b c d e),
% number - position in order. use OrdersToLetters to transform to
% candidates ranked list
function [order]=MajorityRule3(All)
[m,n]=size(All);
temp=NetMarginDiff(All,0);
order=[];
for i=1:(n/2);
    order=[order, ([0 0]+[1,0]*(temp(i)>0)+[0,1]*(temp(i)<0))];
end;
order=ToGeneralizedRankMatrix(order);
n=size(order,2);
if max(abs(sort(order)-(1:n)))==0;
    return;
end;
MatrixOfPrefs=zeros(n,n);
for i=1:(n-1);
    for j=[(i+1):n];
        MatrixOfPrefs(i,j)=temp(sum((n-1):(-1):(n-i+1))+j-i)>=0;
        MatrixOfPrefs(j,i)=temp(sum((n-1):(-1):(n-i+1))+j-i)<=0;
    end;
end;
%disp(MatrixOfPrefs);
for i=1:n;
    for j=[1:(i-1) [(i+1):n]];
        if (MatrixOfPrefs(i,j)==1); % i is weakly better than j
            for k=[[1:(min(i,j)-1)] [(min(i,j)+1):(max(i,j)-1)] [(max(i,j)+1):n]];
                if (MatrixOfPrefs(j,k)==1); % j is weakly  better than k
                    if ~(MatrixOfPrefs(i,k)==1);
                        order(i)=-abs(order(i));
                        order(j)=-abs(order(j));
                        order(k)=-abs(order(k));
                    end;
                end;
            end;
        end;
    end;
end;