function order=ModeRule(All);
n=(sqrt(1+size(All,2)*4)+1)/2;
order=zeros(1,n);
qtemp=AmountInRows(All);
[x1,x2]=max(qtemp);
if size(find(qtemp==x1),1)>1;
    order=zeros(1,n);
    return;
end;
%ToGeneralizedRankMatrix(All(x2,:))
order=VotesToRankings(ToGeneralizedRankMatrix(All(x2,:)),(1:n)',0);