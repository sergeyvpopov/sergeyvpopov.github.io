%NetMarginDiff(Dataset2000,p), p amount of information we need, can be 1 or
%0, if 1 give all values of ab,ac,ad... where ab=(votes for a against b) -
%(votes for be against a)
% [u,i1,i2] - output
%i1 - value of max difference
%i2 - position(cell)
%u - row of differences
function [u,Max,MaxCandidate,Min,MinCandidate]=NetMarginDiff(All,p);
[m,n]=size(All);
u=zeros(m,n/2);
for i=1:2:n;
    u(:,(i+1)/2)=All(:,i)-All(:,i+1);
end;
if (p~=3)&(m>1) u=sum(u);
end;

[Max,MaxCandidate]=max(u);
[Min,MinCandidate]=min(u);