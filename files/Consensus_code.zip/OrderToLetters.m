% turns the list of candidate's ranks to candidate order. candidates are
% A,B,C,D,E,... so if candidate A has rank 2, candidate B has rank 3,
% candidate C has rank 1 the order will be C>A>B. if there is a tie between
% two or more candidates it appears as for ex: C~A>B. if the cycle appears
% or the rule just can not give an order "Something happened" is displayed
function Let=OrderToLetters(order,rule);
n=size(order,2);
if max(abs(order-zeros(1,n)))==0;
    Let='*Undefined*';
    return;
end;
if nargin<2;
    rule=3;
end;
Lett=cellstr(char((65:90)'));
Let='';
if (rule==2).*(max(abs(sort(order)-(1:n)))>0); %Condorcet rule with silliness
    winner=find(order==1);
    loser=find(order==n);
    ord=VotesToRankings(abs(order),(1:n)');
    start=1;
    finish=max(abs(ord));
    if ~isempty(winner);
        %disp('winner');
        Let=[Lett{find(order==1)} '>'];
        start=2;
    end;
    if ~isempty(loser);
        %disp('loser');
        finish=finish-1;
    end;
    Let=[Let '['];
    for i=2:finish;
     pos=find(ord==i);
     m=size(pos,2);
     for j=1:m;
         if order(pos(j))>0;
    
            Let=[Let Lett{pos(j)}];
         else;
             Let=[Let '{' Lett{pos(j)} '}'];
         end;
     end;
    end;
    Let=[Let ']'];
    if ~isempty(loser);
        Let=[Let '>' Lett{find(order==n)}];
    end;
    Let=strrep(Let, '}{', '');
    return;
end;
ord=VotesToRankings(order,(1:n)');
ord(find(order==0))=n;
for i=1:n;
     pos=find(ord==i);
     m=size(pos,2);
     for j=1:m;
      Let=[Let Lett{pos(j)}];
      if (j<m);
          Let=[Let '~'];
      end;
     end;
     if (m>0)&(size(Let,2)<(2*n-1))&(i<n);
         Let=[Let '>'];
     end;
end;
