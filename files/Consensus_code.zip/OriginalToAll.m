function All=OriginalToAll(original,type);

% I assume Original matrix is N+1-sized, with first N columns representing
% preferences, and last column representing quantity of people with such
% ballots.

N=size(original,2)-1;

% by default WO, to get ZW, put 'ZW'
if nargin<2;
    type='WO';
end;

if type=='ZW';
    All=VotesToBinaryRelationship(original(:,1:N)+N*(original(:,1:N)==0));
    for i=1:size(original,1);
        for j=1:N;
            if original(i,j)==0;
                pos=0;
                for k=1:N;
                    if k<j;
                        All(i,pos+2*(j-k)-1)=0;
                        %disp(pos+2*(j-k)-1);
                    elseif (k==j)&(j<N);
                        All(i,(pos+1):(pos+2*(N-j)))=0;
                        %disp((pos+1):(pos+2*(N-j)));
                    end;
                    pos=pos+(N-k)*2;
                end;
            end;
        end;
    end;
         All=All.*kron(ones(1,size(All,2)),original(:,N+1));
 else;
         All=   VotesToBinaryRelationship(original(:,1:N)+N*(original(:,1:N)==0)).*kron(ones(1,(N.^2-N)),original(:,N+1));
end;
