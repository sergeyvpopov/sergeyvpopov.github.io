% parameters are the same as in log likelihood, N - number of voters in
% has more parameters + voting for 1 only, voting for 2 only... (N-1) more
% parameters
% each iterations
function original=ParametricBootstrap2(N,pars,cand);
original=[];
F=prod(1:cand);
par1=[pars(1:(F-1));
1-sum(pars(1:(F-1)));
pars(F:(F+cand-2));
1-sum(pars(F:(F+cand-2)))];

mpl=MakePermutationsOfLinear([1:cand]);

for i=1:N;
    temp=mpl(min(find(cumsum(par1(1:F))>rand)),:);
    temp=temp-temp.*(temp>min(find(rand<cumsum(par1((F+1):(F+cand))))));
    original=[original;temp];
end;
original=summarizeBallots(original);