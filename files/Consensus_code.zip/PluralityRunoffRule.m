function [order,Ties]=PluralityRunoffRule(All);
n=(sqrt(1+size(All,2)*4)+1)/2; % getting amount of candidates from All matrix
qtemp=AmountInRows(All);
order=qtemp'*(ToGeneralizedRankMatrix(All)==1);
if max(order)>(sum(order)/2);
    order=1*(order==max(order))+n*(order~=max(order));
    Ties=0;
    return;
end;
if (max(order)==(sum(order)/2))&(size(find(order==2*n))~=[1 1]); % what does this mean?
    order=1*(order==max(order))+n*(order~=max(order));
    Ties=1;
    return;
end;
if (size(find(VotesToRankings(-order,1:n)>2),2)<n-2); % if tie in seconds
    order=1*(order==max(order))+n*(order~=max(order));
    Ties=1;
    return;
end;
order=VotesToRankings(-order,1:n);
[order,Ties]=PluralityRunoffRule(STVRuleDropFromAll(All,find(order>2)));
