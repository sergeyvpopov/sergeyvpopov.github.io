function prob=ProbThatLosersAreSame(order1, order2);
R=size(order1,1);
prob=sum((WinnerOfChoice(6-order1)==WinnerOfChoice(6-order2)).*(WinnerOfChoice(6-order1)~=0))/R;