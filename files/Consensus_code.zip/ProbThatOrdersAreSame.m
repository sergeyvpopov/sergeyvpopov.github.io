function prob=ProbThatOrdersAreSame(order1, order2);
q=size(order1,2);
R=size(order1,1);
k=1:(q*(q-1));
k=2.^(k-1);
wo1=VotesToBinaryRelationship(order1)*k';
wo2=VotesToBinaryRelationship(order2)*k';
prob=sum((wo1==wo2)')'/R;