function prob=ProbThatWinnerChooseLoser(order1, order2)
R=size(order1,1);
prob=sum((WinnerOfChoice(order1)==WinnerOfChoice(6-order2)).*(WinnerOfChoice(6-order2)~=0).*(WinnerOfChoice(order1)~=0))/R;