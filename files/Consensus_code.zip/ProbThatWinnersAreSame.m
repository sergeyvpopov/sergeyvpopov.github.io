function prob=ProbThatWinnersAreSame(order1, order2);
R=size(order1,1);
prob=sum((WinnerOfChoice(order1)==WinnerOfChoice(order2)).*(WinnerOfChoice(order1)~=0))/R;

%Prob that winners in Condorcet, Borda,Plur, Neg Plur, Alternative voting
%have unique and identical winner. use for complete order or as a part of
%cycle:

%prob=sum((WinnerOfChoice(orders(:,:,1))==WinnerOfChoice(orders(:,:,2))).*(WinnerOfChoice(orders(:,:,1))~=0).*(WinnerOfChoice(orders(:,:,1))==WinnerOfChoice(orders(:,:,3))).*(WinnerOfChoice(orders(:,:,1))==WinnerOfChoice(orders(:,:,4))).*(WinnerOfChoice(orders(:,:,1))==WinnerOfChoice(orders(:,:,5))).*(WinnerOfChoice(orders(:,:,2))~=0).*(WinnerOfChoice(orders(:,:,3))~=0).*(WinnerOfChoice(orders(:,:,4))~=0).*(WinnerOfChoice(orders(:,:,5))~=0))/1000
