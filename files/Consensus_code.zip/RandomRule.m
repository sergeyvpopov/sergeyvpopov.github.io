% Random rule
% input - matrix wo2000, output - row of order, column - candidate (a b c d e),
% number - position in order
function [order]=RandomRule(All);
q=AmountInRows(All);
n=(sqrt(1+size(All,2)*4)+1)/2; % getting amount of candidates from All matrix
a=sign(All(generate_pseudosample(q,1),:));
%ToGeneralizedRankMatrix(a)
order=VotesToRankings(ToGeneralizedRankMatrix(a),1:n);