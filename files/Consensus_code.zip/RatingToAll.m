function All=RatingToAll(ratings,maxval,minval,K,treat);

% I assume ratings matrix is N+1-sized, with first N columns representing
% preferences, and last column representing quantity of people with such
% ballots.
% treat=0 means I ignore the NANs, treat=1 means I treat them as the worst
% choices

N=size(ratings,2)-1;
q=ratings(:,N+1);
direction=sign(maxval-minval);
All=[];
h = waitbar(0,'Converting data, please wait...');
for j=1:size(ratings,1);
    temp=zeros(1,N*(N-1));
    for i=1:(N-1);
        if (isnan(ratings(j,i)))&(treat==0);
        elseif (isnan(ratings(j,i)))&(treat==1);
            
            temp(2*sum((N-i+1):(N-1))+(1:2*(N-i)))=kron(1-isnan(ratings(j,(i+1):N)),[0 1]);
        else;
            for t=(i+1):N;
                if isnan(ratings(j,t));
                    temp(2*sum((N-i+1):(N-1))+(t-i)*2-1)=1*treat;
                    continue;
                end;
                if (ratings(j,i)-ratings(j,t))*direction>K;
                    temp(2*sum((N-i+1):(N-1))+(t-i)*2-2+(1:2))=[1 0];
                elseif (ratings(j,i)-ratings(j,t))*direction<-K;
                    temp(2*sum((N-i+1):(N-1))+(t-i)*2-2+(1:2))=[0 1];
                end;
            end;
        end;    
    end;
    All=[All; temp*q(j)];
    waitbar(j/size(ratings,1));
end;
close(h);