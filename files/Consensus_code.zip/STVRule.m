% STV Rule, hare rule, alternative voting
% input - matrix wo2000, output - row of order, column - candidate (a b c d e),
% number - number of votes, to get an order use STVOrder
function [order,droporder_stv]=STVRule(All,m);

if (nargin<2);
    m=1;
end;
n=(sqrt(1+size(All,2)*4)+1)/2; % getting amount of candidates from All matrix
qtemp=AmountInRows(All);
plur=qtemp'*(ToGeneralizedRankMatrix(All)==1);
if sum(plur)==0;
    order=zeros(1,n);
    return;
end;

droop=sum(plur)/(m+1)+1;
droporder_stv=[];
if (m==n);
    order=plur;
else
    temp=sort(plur);
    Alladj=All;
    order=qtemp'*(ToGeneralizedRankMatrix(All,droporder_stv)==1);
    while ((temp(n+1-m)<droop)&(size(droporder_stv,2)+m<n));
        plur=qtemp'*(ToGeneralizedRankMatrix(All,droporder_stv)==1);
        plur(droporder_stv)=NaN;
        [~, pos]=min(plur);
        if size(find(plur==plur(pos)),2)~=1;
            order=zeros(1,n); %there are multiple minima, or we excluded everybody
            return;
        end;
        droporder_stv=[droporder_stv pos(1)];
        Alladj=STVRuleDropFromAll(All,droporder_stv);
        order=qtemp'*(ToGeneralizedRankMatrix(Alladj,droporder_stv)==1);
        extra=max(order-droop,0);
        k=find(extra>0);       
      
        for i=k;
            temp=ToGeneralizedRankMatrix(All);
            Alladj=All(find(temp(:,i)==1),:);
            plur=sum(kron(AmountInRows(Alladj),ones(1,size(ToGeneralizedRankMatrix(Alladj,[droporder_stv k]),2))).*(ToGeneralizedRankMatrix(Alladj,[droporder_stv k])==1));
            if sum(plur)>0;
                order=order+extra(i)*plur/sum(plur);
            end;
        end;
        temp=sort(order);
        droop=sum(temp)/(m+1)+1;
    end;
end;
