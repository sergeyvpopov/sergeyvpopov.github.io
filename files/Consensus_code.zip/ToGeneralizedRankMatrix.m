%transfer data to Generalised Rank matrix.
%input - original matrix binary relationship (20*less than 325) columns (ab ba ac ca ...)
%output - generalised rank matrix according to article Regenwetter and
%Rykhlevskaya (A general concept scoring rules)
function [V]=ToGeneralizedRankMatrix(All,k);
if nargin<2;
    k=[];
end;
% k are those who we want to throw away from All matrix
% size of input Matrix with binary relationships (always 20 columns)  
n=(sqrt(1+size(All,2)*4)+1)/2; % getting amount of candidates from All matrix
%counting votes for particular candidate 
if n==1;
    V=ones(size(All,1),n);
    return;
end;
V=zeros(size(All,1),n);
if isempty(k);
    diff=NetMarginDiff(All,3);
    q=AmountInRows(All);
    ind=0;
    for a=1:(n-1);
        for b=(a+1):n;
          j=ind+b-a;  
          V(:,a)=V(:,a)-diff(:,j);
          V(:,b)=V(:,b)+diff(:,j);
        end;
        ind=ind+n-a;
    end;

    for j=1:n;
        %V(:,j)=(n-1)*q*(1-(size(find(k==j),2)==0))+V(:,j)*(size(find(k==j),2)==0);
        nonneg=find(q>0);
        V(nonneg,j)=(n+1)/2+V(nonneg,j)./(2*q(nonneg,1));
        nonneg=find(q==0);
        V(nonneg,j)=(n+1)/2;
    end;
else;
    tokeep=ones(1,size(All,2));
    temp=0:n-1;
    temp=2*temp*n-temp.*(temp+1);
    for i=(1:size(All,2));
        leftguy=max(find(temp<i));
        rightguy=leftguy+ceil((i-temp(leftguy))/2);
        
        tokeep(i)=isempty(find(k==leftguy)).*isempty(find(k==rightguy));
    end;
    %disp(All(:,find(tokeep==1)));
    temp=ToGeneralizedRankMatrix(All(:,find(tokeep==1)));
    for i=1:n;
        if isempty(find(k==i));
            V(:,i)=temp(:,i-size(find(k<i),2));
        end;
    end;
end;