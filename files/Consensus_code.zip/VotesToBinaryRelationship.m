% transfer to binary relationship
%input matrix of ranking 5*n, each row 1 2 3 4 5, output matrix 20*n, each
%raw 1 0 1 0 1 1 0 ... ab-1 ba-2 ac-3 ca-4 ad-5 da...
% work for zw model. if 123(45 -don't exist) then transfer to bin

function [binary]=VotesToBinaryRelationship(wo);
[m,n]=size(wo);

if n==2;
    binary=zeros(m,2);
    binary(:,1)=((wo(:,1)<wo(:,2))+(wo(:,2)==0)).*(wo(:,1)>0);
    binary(:,2)=((wo(:,2)<wo(:,1))+(wo(:,1)==0)).*(wo(:,2)>0);
else;
    binary=zeros(m,2*(n-1));% VotesToBinaryRelationship(wo(:,2:n))];
    binary=[binary VotesToBinaryRelationship(wo(:,2:n))];
    for i=2:n;
        binary(:,2*i-3)=((wo(:,1)<wo(:,i))+(wo(:,i)==0)).*(wo(:,1)>0);
        binary(:,2*i-2)=((wo(:,i)<wo(:,1))+(wo(:,1)==0)).*(wo(:,i)>0);
    end;
end;

% binary=zeros(m,20);
% 
% binary(:,1)=((wo(:,1)<wo(:,2))+(wo(:,2)==0)).*(wo(:,1)>0);
% binary(:,2)=((wo(:,2)<wo(:,1))+(wo(:,1)==0)).*(wo(:,2)>0);
% 
% binary(:,3)=((wo(:,1)<wo(:,3))+(wo(:,3)==0)).*(wo(:,1)>0);
% binary(:,4)=((wo(:,3)<wo(:,1))+(wo(:,1)==0)).*(wo(:,3)>0);
% 
% binary(:,5)=((wo(:,1)<wo(:,4))+(wo(:,4)==0)).*(wo(:,1)>0);
% binary(:,6)=((wo(:,4)<wo(:,1))+(wo(:,1)==0)).*(wo(:,4)>0);
% 
% binary(:,7)=((wo(:,1)<wo(:,5))+(wo(:,5)==0)).*(wo(:,1)>0);
% binary(:,8)=((wo(:,5)<wo(:,1))+(wo(:,1)==0)).*(wo(:,5)>0);
% 
% binary(:,9)=((wo(:,2)<wo(:,3))+(wo(:,3)==0)).*(wo(:,2)>0);
% binary(:,10)=((wo(:,3)<wo(:,2))+(wo(:,2)==0)).*(wo(:,3)>0);
% 
% binary(:,11)=((wo(:,2)<wo(:,4))+(wo(:,4)==0)).*(wo(:,2)>0);
% binary(:,12)=((wo(:,4)<wo(:,2))+(wo(:,2)==0)).*(wo(:,4)>0);
% 
% binary(:,13)=((wo(:,2)<wo(:,5))+(wo(:,5)==0)).*(wo(:,2)>0);
% binary(:,14)=((wo(:,5)<wo(:,2))+(wo(:,2)==0)).*(wo(:,5)>0);
% 
% binary(:,15)=((wo(:,3)<wo(:,4))+(wo(:,4)==0)).*(wo(:,3)>0);
% binary(:,16)=((wo(:,4)<wo(:,3))+(wo(:,3)==0)).*(wo(:,4)>0);
% 
% binary(:,17)=((wo(:,3)<wo(:,5))+(wo(:,5)==0)).*(wo(:,3)>0);
% binary(:,18)=((wo(:,5)<wo(:,3))+(wo(:,3)==0)).*(wo(:,5)>0);
% 
% binary(:,19)=((wo(:,4)<wo(:,5))+(wo(:,5)==0)).*(wo(:,4)>0);
% binary(:,20)=((wo(:,5)<wo(:,4))+(wo(:,4)==0)).*(wo(:,5)>0);

