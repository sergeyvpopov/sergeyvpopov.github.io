% example of input: VotesToRankings(ToGeneralizedRankMatrix(wo2001),[1 2 3 4
% 5])
%input - generalised rank matrix for particular year and ranking which we
%want to get in result matrix. 1 is for lowest rank (highest position)
%candidate and so on...
%output - matrix with ranking according to generalised matrix (have only integers in it)
function [v]=VotesToRankings(votes,vals,keepzero);
if nargin<3;
    keepzero=1;
end;
temp=votes;
[m,n]=size(votes);
ans=votes;
for i=1:m;
    for j=1:n;
        if (min(temp(i,:)))==Inf; 
            break; 
        end;
       % if ((min(temp(i,:)))<1)&(keepzero==1);
       %     zeropos=find(temp(i,:)==0);
       %     temp(i,zeropos)=Inf;
       %     ans(i,zeropos)=5;
       % end;
        pos=find(temp(i,:)==min(temp(i,:)));
        ans(i,pos)=vals(j);
        temp(i,pos)=Inf;
    end;
end;
v=ans;
%can be used to calculate plurality, negative plurality (wsr), k approval
%voting