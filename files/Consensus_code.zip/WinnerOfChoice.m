function [CandidateNumber]=WinnerOfChoice(wo);
% If choice has two winners or cycle, there is no winner
[m,n]=size(wo);
[i,j]=find(wo'==ones(m,n)');
res=[i j];
CandidateNumber=zeros(m,1);
for k=1:m;
 if (size(find(res(:,2)==k))==1);   
  CandidateNumber(k,1)=res(find(res(:,2)==k),1);
 end;
end; 