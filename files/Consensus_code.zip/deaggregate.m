function deagg=deaggregate(All);

deagg=sign(All);
qtemp=AmountInRows(All);
for i=1:size(qtemp,1);
if qtemp(i)>1;
        deagg=[deagg;kron(ones(qtemp(i)-1,1), deagg(i,:))];
end;
end;