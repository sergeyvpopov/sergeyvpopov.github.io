function [v]=generate_pseudosample(q,n)

temp=1:n;
pos=cumsum(q)/sum(q); %
for i=1:n;
    temp(i)=min(find(pos>unifrnd(0,1))); %unifrnd(0,1) - random variable
    % procedure picks a row of linear orders to choose!
end;
v=temp;