function varargout = socialChoice(varargin)
% SOCIALCHOICE M-file for socialChoice.fig
%      SOCIALCHOICE, by itself, creates a new SOCIALCHOICE or raises the existing
%      singleton*.
%
%      H = SOCIALCHOICE returns the handle to a new SOCIALCHOICE or the handle to
%      the existing singleton*.
%
%      SOCIALCHOICE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SOCIALCHOICE.M with the given input arguments.
%
%      SOCIALCHOICE('Property','Value',...) creates a new SOCIALCHOICE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before socialChoice_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to socialChoice_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help socialChoice

% Last Modified by GUIDE v2.5 03-Apr-2012 12:13:30

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @socialChoice_OpeningFcn, ...
                   'gui_OutputFcn',  @socialChoice_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before socialChoice is made visible.
function socialChoice_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to socialChoice (see VARARGIN)

% Choose default command line output for socialChoice
handles.output = hObject;












% ADDED TO CHANGE THE NAME IN THE BLUE LINE TITLE****************

%feature('DefaultCharacterSet','UTF-8');
%figure('Name',['CONS',398,'NSUS']);

%feature('defaultcharacterset','UTF-8');
%set(hObject, 'Name', ['CONS',398,'NSUS']);
%set(hObject, 'Name', [char(unicode2native(['?',23]))]);
%set(hObject, 'Name', [char(['?',501:600])]);










set(handles.radiobutton_FileUploadCSV,'Value',1)
handles.UploadChoice = 1;

set(handles.edit_FileLocation,'String',fullfile(pwd))

set(handles.edit_numCandidates,'Enable','inactive');
set(handles.text_numCandidates,'Enable','on');
set(handles.edit_numVotersInData,'Enable','inactive');
set(handles.text_numVotersInData,'Enable','on');
set(handles.edit_numCandidates,'string','');
set(handles.edit_numVotersInData,'string','');

set(handles.popupmenu_CultType,'Enable','off');
set(handles.popupmenu_DataType,'Enable','off');   
set(handles.listbox_RankedData,'Enable','off');
set(handles.listbox_PartialData,'Enable','off');

set(handles.listbox_OriginalDatasetResults,'Enable','off')
set(handles.pushbutton_ResultTable,'Enable','off')
%set(handles.pushbutton_ExportResults,'Enable','off')

% u = uicontrol('style','listbox','string','Option1|Option2|Option3|Option4|Option5',...
% 'position',[10 10 75 50]);

%show the 'for all' and 'beta' symbols
%labelStr = '<html>&#8704;&#946; <b>bold</b> <i><font color="red">label</html>';
%jLabel = javaObjectEDT('javax.swing.JLabel',labelStr);
%[hcomponent,hcontainer] = javacomponent(jLabel,[100,100,40,20],gcf);

%%%%%%%%%%%%%%%%%%%%%%INITIAL DATA%%%%%%%%%%%%%%%
handles.dispOnScreen = 1;
handles.UploadChoice = 1;
handles.data = '';
handles.fileName= '';
%handles.numVoters= 0;
%handles.numCandidates= 0;

handles.DataType = 0;
handles.RankedData = 0;
handles.PartialData = 0;

handles.CultDataType = 0;
handles.CultRankedData = 0;
handles.CultPartialData = 0;

handles.isactiveRulesToApply = 0;
handles.numRandomSeed = 0;
handles.numIterations = 100;

handles.Rules = 0;
handles.HighRep = 2;
handles.RegRep = 0.5; 

handles.ResultData=0;
handles.AggRules = 0 ;

handles.TotalResults=0;

%%%%%%%%%%%%%%%%%%%%%%INITIAL DATA ENDS %%%%%%%%%%%%%%%

if handles.dispOnScreen  
    handles
end
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes socialChoice wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = socialChoice_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
% Update handles structure
guidata(hObject, handles);

% --- Executes when selected object is changed in uipanel_FileSelection.
function uipanel_FileSelection_SelectionChangeFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in uipanel_FileSelection 
% eventdata  structure with the following fields (see UIBUTTONGROUP)
%	EventName: string 'SelectionChanged' (read only)
%	OldValue: handle of the previously selected object or empty if none was selected
%	NewValue: handle of the currently selected object
% handles    structure with handles and user data (see GUIDATA)
%%%%%%%%%%%%%%%%%%%%%%INITIAL DATA%%%%%%%%%%%%%%%
handles.UploadChoice = 0;
handles.data = '';
handles.fileName= '';
handles.numVoters= 0;
handles.numCandidates= 0;

handles.DataType = 0;
handles.RankedData = 0;
handles.PartialData = 0;


handles.CultDataType = 0;
handles.CultRankedData = 0;
handles.CultPartialData = 0;

handles.isactiveRulesToApply = 0;

handles.Rules = 0;
handles.HighRep = 2;
handles.RegRep = 0.5; 

handles.ResultData=0;

handles.AggRules = 0 ;
%%%%%%%%%%%%%%%%%%%%%%INITIAL DATA ENDS %%%%%%%%%%%%%%%


if (hObject == handles.radiobutton_FileUploadCSV)
    handles.UploadChoice = 1;
    set(handles.pushbutton_FileChooser,'Enable','on');
    set(handles.edit_FileLocation,'Enable','on');
    set(handles.text_FileLocation,'Enable','on');
    set(handles.edit_numCandidates,'Enable','inactive');
    set(handles.text_numCandidates,'Enable','on');
    set(handles.edit_numVotersInData,'Enable','inactive');
    set(handles.text_numVotersInData,'Enable','on');
    set(handles.edit_numCandidates,'string','');
    set(handles.edit_numVotersInData,'string','');
    %set(handles.uipanel_DataSetOptions,'Visible','off');
    
    
    set(handles.text_DataChoices,'Enable','off');
    set(handles.popupmenu_DataType,'Enable','off');   
    set(handles.listbox_RankedData,'Enable','off');
    set(handles.listbox_PartialData,'Enable','off');
    
    set(handles.text_CultType,'Enable','off')
    set(handles.popupmenu_CultType,'Enable','off');
    set(handles.listbox_CultRankedData,'Enable','off');
    set(handles.listbox_CultPartialData,'Enable','off');
    
    set(handles.listbox_ApplyRules,'Enable','off');
    set(handles.text_numIterations,'Enable','off');
    set(handles.edit_numIterations,'Enable','off');
    set(handles.text_numVoters,'Enable','off');
    set(handles.edit_numVoters,'Enable','off');
    set(handles.text_randomSeed,'Enable','off');
    set(handles.edit_randomSeed,'Enable','off');
    
    
    
    
elseif (hObject == handles.radiobutton_FileUploadSIM)
    handles.UploadChoice = 2;
    
    set(handles.pushbutton_FileChooser,'Enable','off');
    set(handles.edit_FileLocation,'Enable','off');
    set(handles.text_FileLocation,'Enable','off');
    set(handles.edit_numCandidates,'Enable','inactive');
    set(handles.text_numCandidates,'Enable','on');
    set(handles.edit_numVotersInData,'Enable','inactive');
    set(handles.text_numVotersInData,'Enable','on');
    
    set(handles.text_DataChoices,'Enable','off')
    set(handles.popupmenu_DataType,'Enable','off');   
    set(handles.listbox_RankedData,'Enable','off');
    set(handles.listbox_PartialData,'Enable','off');

    set(handles.edit_numCandidates,'string','');
    set(handles.edit_numVotersInData,'string','');
    set(handles.edit_numVoters,'string','');

    
    
    prompt={'Specify Number of Voters',...
            'Specify Number of Candidates'};
    name='Voters & Candidates Information';
    numlines=1;
    defaultanswer={'',''};
    answer=inputdlg(prompt,name,numlines,defaultanswer);
    
    
    if isempty(answer) 
        set(handles.radiobutton_FileUploadCSV,'Value',2);
        handles.UploadChoice = 2;
        set(handles.pushbutton_FileChooser,'Enable','on');
        set(handles.edit_FileLocation,'Enable','on');
        set(handles.text_FileLocation,'Enable','on');
       return; 
    end
    
    numVoters=str2double(answer(1));
    if isempty(numVoters) || ~isfinite(numVoters); return; end
    maxNumVoters = 100000000;
    minNumVoters = 1;

    numCandidates=str2double(answer(2));
    maxNumCandidates = 20;
    minNumCandidates = 3;
    
    if numVoters <minNumVoters || numVoters >maxNumVoters  
        msgbox(['Number of Voters should be between ' num2str(minNumVoters) ' and ' ...
            num2str(maxNumVoters)],'Error','modal');
        uiwait; 
        set(handles.radiobutton_FileUploadCSV,'Value',2);
        handles.UploadChoice = 2;
        set(handles.pushbutton_FileChooser,'Enable','on');
        set(handles.edit_FileLocation,'Enable','on');
        set(handles.text_FileLocation,'Enable','on');
        return;
    elseif (floor(numVoters) - numVoters) ~= 0
        msgbox('Incorrect number of Voters: Please check your number of Voters!', 'Error','modal');
        uiwait;
        set(handles.radiobutton_FileUploadCSV,'Value',2);
        handles.UploadChoice = 2;
        set(handles.pushbutton_FileChooser,'Enable','on');
        set(handles.edit_FileLocation,'Enable','on');
        set(handles.text_FileLocation,'Enable','on');
        return;
    end
    
    if numCandidates <minNumCandidates || numCandidates>maxNumCandidates  
        msgbox(['Number of Candidates should be between ' num2str(minNumCandidates) ' and ' ...
            num2str(maxNumCandidates)],'Error','modal');
        uiwait; 
        set(handles.radiobutton_FileUploadCSV,'Value',2);
        handles.UploadChoice = 2;
        set(handles.pushbutton_FileChooser,'Enable','on');
        set(handles.edit_FileLocation,'Enable','on');
        set(handles.text_FileLocation,'Enable','on');
        return;
    elseif (floor(numCandidates) - numCandidates) ~= 0
        msgbox('Incorrect number of Candidates: Please check your input file!');
        uiwait;
        set(handles.radiobutton_FileUploadCSV,'Value',2);
        handles.UploadChoice = 2;
        set(handles.pushbutton_FileChooser,'Enable','on');
        set(handles.edit_FileLocation,'Enable','on');
        set(handles.text_FileLocation,'Enable','on');
        return;
    end
    
    strCandidates = num2str(numCandidates);
    set(handles.edit_numCandidates,'string',strCandidates);
    handles.numCandidates = numCandidates;
    
    set(handles.edit_numVoters,'string',numVoters);
    set(handles.edit_numVotersInData,'string',numVoters);
    handles.numVoters = numVoters;
    
    set(handles.text_CultType,'Enable','on')
    set(handles.popupmenu_CultType,'Enable','on');
    set(handles.listbox_CultRankedData,'Enable','off');
    set(handles.listbox_CultPartialData,'Enable','off');
    
    set(handles.listbox_ApplyRules,'Enable','off');
    set(handles.text_numIterations,'Enable','off');
    set(handles.edit_numIterations,'Enable','off');
    set(handles.text_numVoters,'Enable','off');
    set(handles.edit_numVoters,'Enable','off');
    set(handles.text_randomSeed,'Enable','off');
    set(handles.edit_randomSeed,'Enable','off');
end;


handles.isactiveRulesToApply = 0;
set(handles.listbox_ApplyRules,'Enable','off');
set(handles.text_numIterations,'Enable','off');
set(handles.edit_numIterations,'Enable','off');
set(handles.text_numVoters,'Enable','off');
set(handles.edit_numVoters,'Enable','off');
set(handles.text_randomSeed,'Enable','off');
set(handles.edit_randomSeed,'Enable','off');
set(handles.pushbutton_StartAnalysis,'Enable','off');

if handles.dispOnScreen  
    handles
end

% Update handles structure
guidata(hObject, handles);


% --- Executes on button press in pushbutton_FileChooser.
function pushbutton_FileChooser_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_FileChooser (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


%%%%%%%%%%%%%%%%%%%%%%INITIAL DATA%%%%%%%%%%%%%%%
handles.data = '';
handles.fileName= '';
handles.numVoters= 0;
handles.numCandidates= 0;

handles.DataType = 0;
handles.RankedData = 0;
handles.PartialData = 0;

handles.CultDataType = 0;
handles.CultRankedData = 0;
handles.CultPartialData = 0;

handles.isactiveRulesToApply = 0;

handles.Rules = 0;
handles.HighRep = 2;
handles.RegRep = 0.5; 

handles.ResultData=0;

handles.AggRules = 0 ;
%%%%%%%%%%%%%%%%%%%%%%INITIAL DATA ENDS %%%%%%%%%%%%%%%


[filename, pathname] = uigetfile('*.csv', 'Load a csv-file');
if isequal(filename,0)
   disp('User selected Cancel');
   return;
else
   disp(['User selected ', fullfile(pathname, filename)])
end

if filename ~= 0
    set(handles.edit_FileLocation,'String',fullfile(pathname, filename))
    handles.fileName = [pathname filename];
    
    data = load([pathname filename]);
    handles.data = data;    
    
    set(handles.text_DataChoices,'Enable','on');
    set(handles.popupmenu_DataType,'Enable','on');   

end

handles.isactiveRulesToApply = 0;
set(handles.listbox_ApplyRules,'Enable','off');
set(handles.text_numIterations,'Enable','off');
set(handles.edit_numIterations,'Enable','off');
set(handles.text_numVoters,'Enable','off');
set(handles.edit_numVoters,'Enable','off');
set(handles.text_randomSeed,'Enable','off');
set(handles.edit_randomSeed,'Enable','off');
set(handles.pushbutton_StartAnalysis,'Enable','off');

if handles.dispOnScreen  
    handles
end

% Update handles structure
guidata(hObject, handles);



function edit_FileLocation_Callback(hObject, eventdata, handles)
% hObject    handle to edit_FileLocation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_FileLocation as text
%        str2double(get(hObject,'String')) returns contents of edit_FileLocation as a double


% --- Executes during object creation, after setting all properties.
function edit_FileLocation_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_FileLocation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_numCandidates_Callback(hObject, eventdata, handles)
% hObject    handle to edit_numCandidates (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_numCandidates as text
%        str2double(get(hObject,'String')) returns contents of edit_numCandidates as a double


% --- Executes during object creation, after setting all properties.
function edit_numCandidates_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_numCandidates (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_numVoters_Callback(hObject, eventdata, handles)
% hObject    handle to edit_numVoters (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_numVoters as text
%        str2double(get(hObject,'String')) returns contents of edit_numVoters as a double


% --- Executes during object creation, after setting all properties.
function edit_numVoters_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_numVoters (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton_LockDataFile.
function pushbutton_LockDataFile_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_LockDataFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in listbox_ApplyRules.
function listbox_ApplyRules_Callback(hObject, eventdata, handles)
% hObject    handle to listbox_ApplyRules (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox_ApplyRules contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox_ApplyRules

%%%%%%%%%%%%%%%%%%%%%%INITIAL DATA%%%%%%%%%%%%%%%
handles.isactiveRulesToApply = 0;

handles.Rules = 0;
handles.HighRep = 2;
handles.RegRep = 0.5; 

handles.ResultData=0;

handles.AggRules = 0 ;
%%%%%%%%%%%%%%%%%%%%%%INITIAL DATA ENDS %%%%%%%%%%%%%%%

valRules = get(hObject, 'Value');
strRules = get(hObject, 'String');

if valRules == 1 
    handles.isactiveRulesToApply = 0;
    handles.Rules = valRules;
    msgbox('You need to choose at least one rule!','Error','modal');
    set(handles.text_numIterations,'Enable','off');
    set(handles.edit_numIterations,'Enable','off');
    set(handles.text_numVoters,'Enable','off');
    set(handles.edit_numVoters,'Enable','off');
    set(handles.text_randomSeed,'Enable','off');
    set(handles.edit_randomSeed,'Enable','off');
    set(handles.pushbutton_StartAnalysis,'Enable','off');
    return
else 
    handles.isactiveRulesToApply = 1;
    handles.Rules = valRules;
    set(handles.text_numIterations,'Enable','on');
    set(handles.edit_numIterations,'Enable','on');
    set(handles.text_numVoters,'Enable','on');
    set(handles.edit_numVoters,'Enable','on');
    set(handles.text_numVoters,'Enable','on');
    set(handles.edit_numVoters,'Enable','on');
    set(handles.text_randomSeed,'Enable','on');
    set(handles.edit_randomSeed,'Enable','on');
    set(handles.pushbutton_StartAnalysis,'Enable','on');
end;

if handles.dispOnScreen  
    handles
end

% Update handles structure
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function listbox_ApplyRules_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox_ApplyRules (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in togglebutton_OutputOptions.
function togglebutton_OutputOptions_Callback(hObject, eventdata, handles)
% hObject    handle to togglebutton_OutputOptions (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of togglebutton_OutputOptions


% --- Executes on button press in togglebutton2.
function togglebutton2_Callback(hObject, eventdata, handles)
% hObject    handle to togglebutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of togglebutton2


% --- Executes on button press in togglebutton3.
function togglebutton3_Callback(hObject, eventdata, handles)
% hObject    handle to togglebutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of togglebutton3


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over togglebutton4.
function togglebutton4_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to togglebutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in listbox_SIMoptions.
function listbox_SIMoptions_Callback(hObject, eventdata, handles)
% hObject    handle to listbox_SIMoptions (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox_SIMoptions contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox_SIMoptions


% --- Executes during object creation, after setting all properties.
function listbox_SIMoptions_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox_SIMoptions (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end






% --- Executes on button press in checkbox_SIMother.
function checkbox_SIMother_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox_SIMother (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox_SIMother


% --- Executes on key press with focus on edit_numVoters and none of its controls.
function edit_numVoters_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to edit_numVoters (see GCBO)
% eventdata  structure with the following fields (see UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton_UnlockDataFile.
function pushbutton_UnlockDataFile_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_UnlockDataFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in popupmenu_DataType.
function popupmenu_DataType_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu_DataType (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu_DataType contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu_DataType
%%%%%%%%%%%%%%%%%%%%%%INITIAL DATA%%%%%%%%%%%%%%%
handles.numVoters= 0;
handles.numCandidates= 0;

handles.DataType = 0;
handles.RankedData = 0;
handles.PartialData = 0;

handles.CultDataType = 0;
handles.CultRankedData = 0;
handles.CultPartialData = 0;

handles.isactiveRulesToApply = 0;

handles.Rules = 0;
handles.HighRep = 2;
handles.RegRep = 0.5; 

handles.ResultData=0;

handles.AggRules = 0 ;

set(handles.listbox_RankedData,'Visible','off');
set(handles.listbox_PartialData,'Visible','off');
set(handles.BestRating,'Visible','off');
set(handles.WorstRating,'Visible','off');
set(handles.RatingThreshold,'Visible','off');
set(handles.RatingTreatMissing,'Visible','off');
set(handles.text33,'Visible','off');
set(handles.text34,'Visible','off');
set(handles.text35,'Visible','off');


%%%%%%%%%%%%%%%%%%%%%%INITIAL DATA ENDS %%%%%%%%%%%%%%%

valDataType = get(hObject, 'Value');
strDataType = get(hObject, 'String');
handles.DataType = valDataType;

switch valDataType 
    case 1 %Selection Other Data Title
        msgbox('You need to choose Data Type!','Error','modal');
        set(handles.listbox_RankedData,'Enable','off'); 
        set(handles.listbox_PartialData,'Enable','off');
        set(handles.listbox_ApplyRules,'Enable','off');
        handles.numCandidates = 0;
        handles.numVoters  = 0;
        return
    case 2 %Selection Binary Data     
        numCandidates=(sqrt(1+4*size(handles.data,2))+1)/2;
        handles.numCandidates = numCandidates;
        
        numVoters = sum(max(handles.data'));
        handles.numVoters  = numVoters;
        
        set(handles.listbox_RankedData,'Enable','off'); 
        set(handles.listbox_RankedData,'Visible','off');
        set(handles.listbox_PartialData,'Enable','off');
        set(handles.listbox_ApplyRules,'Enable','on');
        set(handles.text_numIterations,'Enable','off');
        set(handles.edit_numIterations,'Enable','off');
        set(handles.text_numVoters,'Enable','off');
        set(handles.edit_numVoters,'Enable','off');
        set(handles.text_randomSeed,'Enable','off');
        set(handles.edit_randomSeed,'Enable','off');
        
        
    case 3 %Selection Ranked Data
        numVoters = sum(handles.data(:,size(handles.data,2)));
        handles.numVoters  = numVoters;
        numCandidates = size(handles.data,2)-1;
        handles.numCandidates = numCandidates;
        
        set(handles.listbox_RankedData,'Enable','on'); 
        set(handles.listbox_RankedData,'Value',1);
        set(handles.listbox_RankedData,'Visible','on');
        set(handles.listbox_PartialData,'Enable','off');
        set(handles.listbox_ApplyRules,'Enable','off');
        set(handles.text_numIterations,'Enable','off');
        set(handles.edit_numIterations,'Enable','off');
        set(handles.text_numVoters,'Enable','off');
        set(handles.edit_numVoters,'Enable','off');
        set(handles.text_randomSeed,'Enable','off');
        set(handles.edit_randomSeed,'Enable','off');
    case 4 %Selection Rating Data
        numCandidates=size(handles.data,2)-1;
        handles.numCandidates = numCandidates;
        numVoters = sum(handles.data(:,numCandidates+1));
        handles.numVoters  = numVoters;
        
        set(handles.listbox_RankedData,'Enable','off');
        set(handles.listbox_PartialData,'Enable','off');
        set(handles.listbox_ApplyRules,'Enable','off');
        set(handles.text_numIterations,'Enable','off');
        set(handles.edit_numIterations,'Enable','off');
        set(handles.text_numVoters,'Enable','off');
        set(handles.edit_numVoters,'Enable','off');
        set(handles.text_randomSeed,'Enable','off');
        set(handles.edit_randomSeed,'Enable','off');
        
        set(handles.BestRating,'Visible','on');
        set(handles.WorstRating,'Visible','on');
        set(handles.RatingThreshold,'Visible','on');
        set(handles.RatingTreatMissing,'Visible','on');
        set(handles.text33,'Visible','on');
        set(handles.text34,'Visible','on');
        set(handles.text35,'Visible','on');
        
        set(handles.listbox_ApplyRules,'Enable','on');
        set(handles.text_numIterations,'Enable','off');
        set(handles.edit_numIterations,'Enable','off');
        set(handles.text_numVoters,'Enable','off');
        set(handles.edit_numVoters,'Enable','off');
        set(handles.text_randomSeed,'Enable','off');
        set(handles.edit_randomSeed,'Enable','off');
end 


if (floor(numCandidates) - numCandidates) == 0
    disp('Incorrect number of Candidates: Please check your input file!')
%    return
end 
strCandidates = num2str(numCandidates);
set(handles.edit_numCandidates,'string',strCandidates);
strVoters = num2str(numVoters);
set(handles.edit_numVoters,'string',strVoters);
set(handles.edit_numVotersInData,'string',strVoters);


handles.isactiveRulesToApply = 0;

if handles.dispOnScreen  
    handles
end

% Update handles structure
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function popupmenu_DataType_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu_DataType (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in listbox_RankedData.
function listbox_RankedData_Callback(hObject, eventdata, handles)
% hObject    handle to listbox_RankedData (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox_RankedData contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox_RankedData
%%%%%%%%%%%%%%%%%%%%%%INITIAL DATA%%%%%%%%%%%%%%%
handles.RankedData = 0;
handles.PartialData = 0;

handles.CultDataType = 0;
handles.CultRankedData = 0;
handles.CultPartialData = 0;

handles.isactiveRulesToApply = 0;

handles.Rules = 0;
handles.HighRep = 2;
handles.RegRep = 0.5; 

handles.ResultData=0;

handles.AggRules = 0 ;
set(handles.listbox_PartialData,'Visible','off');
%%%%%%%%%%%%%%%%%%%%%%INITIAL DATA ENDS %%%%%%%%%%%%%%%

valRankedData = get(hObject, 'Value');
strRankedData = get(hObject, 'String');

handles.RankedData = valRankedData;

if  valRankedData==1 
    msgbox('Please choose Ranking!','Error','modal');
    set(handles.listbox_PartialData,'Enable','off'); 
    set(handles.listbox_PartialData,'Visible','off');
    set(handles.listbox_ApplyRules,'Enable','off');
    set(handles.text_numIterations,'Enable','off');
    set(handles.edit_numIterations,'Enable','off');
    set(handles.text_numVoters,'Enable','off');
    set(handles.edit_numVoters,'Enable','off');
    set(handles.text_randomSeed,'Enable','off');
    set(handles.edit_randomSeed,'Enable','off');
    return
elseif valRankedData==3 
    set(handles.listbox_PartialData,'Enable','on'); 
    set(handles.listbox_PartialData,'Value',1); 
    set(handles.listbox_PartialData,'Visible','on');
    set(handles.listbox_ApplyRules,'Enable','off');
    set(handles.text_numIterations,'Enable','off');
    set(handles.edit_numIterations,'Enable','off');
    set(handles.text_numVoters,'Enable','off');
    set(handles.edit_numVoters,'Enable','off');
    set(handles.text_randomSeed,'Enable','off')
    set(handles.edit_randomSeed,'Enable','off')
elseif valRankedData == 4 
    msgbox('Option Coming Soon','Error','modal');
    set(handles.listbox_PartialData,'Enable','off'); 
    set(handles.listbox_ApplyRules,'Enable','off');
    set(handles.text_numIterations,'Enable','off');
    set(handles.edit_numIterations,'Enable','off');
    set(handles.text_numVoters,'Enable','on');
    set(handles.edit_numVoters,'Enable','on');
    set(handles.text_randomSeed,'Enable','off');
    set(handles.edit_randomSeed,'Enable','off');
    return
else
    set(handles.listbox_PartialData,'Enable','off');
    set(handles.listbox_ApplyRules,'Enable','on');
    set(handles.text_numIterations,'Enable','off');
    set(handles.edit_numIterations,'Enable','off');
    set(handles.text_randomSeed,'Enable','off');
    set(handles.edit_randomSeed,'Enable','off');
end 

handles.isactiveRulesToApply = 0;

if handles.dispOnScreen  
    handles
end

% Update handles structure
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function listbox_RankedData_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox_RankedData (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in listbox_PartialData.
function listbox_PartialData_Callback(hObject, eventdata, handles)
% hObject    handle to listbox_PartialData (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox_PartialData contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox_PartialData

%%%%%%%%%%%%%%%%%%%%%%INITIAL DATA%%%%%%%%%%%%%%%
handles.CultPartialData = 0;

handles.isactiveRulesToApply = 0;

handles.Rules = 0;
handles.HighRep = 2;
handles.RegRep = 0.5; 

handles.ResultData=0;

handles.AggRules = 0 ;
%%%%%%%%%%%%%%%%%%%%%%INITIAL DATA ENDS %%%%%%%%%%%%%%%

valPartialData = get(hObject, 'Value');
strPartialData = get(hObject, 'String');
handles.PartialData = valPartialData;

if ~isempty(find(valPartialData == 1)) 
    msgbox('Please choose Partial Ranking Model!','Error','modal');
    set(handles.listbox_ApplyRules,'Enable','off');
    set(handles.text_numIterations,'Enable','off');
    set(handles.edit_numIterations,'Enable','off');
    set(handles.text_numVoters,'Enable','off');
    set(handles.edit_numVoters,'Enable','off');
    set(handles.text_randomSeed,'Enable','off');
    set(handles.edit_randomSeed,'Enable','off');
    return
elseif ~isempty(find(valPartialData == 5))
    msgbox('Option "Others" is coming soon, please correct your choice','Error','modal');
    set(handles.listbox_ApplyRules,'Enable','off');
    set(handles.text_numIterations,'Enable','off')
    set(handles.edit_numIterations,'Enable','off')
    set(handles.text_numVoters,'Enable','off');
    set(handles.edit_numVoters,'Enable','off');
    set(handles.text_randomSeed,'Enable','off')
    set(handles.edit_randomSeed,'Enable','off')
    return
elseif ~isempty(find(valPartialData == 2)) || ~isempty(find(valPartialData == 3)) || ~isempty(find(valPartialData == 4))
    set(handles.listbox_ApplyRules,'Enable','on');
    set(handles.text_numIterations,'Enable','off')
    set(handles.edit_numIterations,'Enable','off')
    set(handles.text_numVoters,'Enable','off');
    set(handles.edit_numVoters,'Enable','off');
    set(handles.text_randomSeed,'Enable','off')
    set(handles.edit_randomSeed,'Enable','off')
else 
    set(handles.listbox_ApplyRules,'Enable','off');
    set(handles.text_numIterations,'Enable','off')
    set(handles.edit_numIterations,'Enable','off')
    set(handles.text_numVoters,'Enable','off');
    set(handles.edit_numVoters,'Enable','off');
    set(handles.text_randomSeed,'Enable','off')
    set(handles.edit_randomSeed,'Enable','off')
end 

handles.isactiveRulesToApply = 0;

if handles.dispOnScreen  
    handles
end

% Update handles structure
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function listbox_PartialData_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox_PartialData (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu_DataType.
function popupmenu2_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu_DataType (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu_DataType contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu_DataType


% --- Executes during object creation, after setting all properties.
function popupmenu2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu_DataType (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton_Exit.
function pushbutton_Exit_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_Exit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close all;



% --- Executes during object creation, after setting all properties.
function uipanel_DataSetOptions_CreateFcn(hObject, eventdata, handles)
% hObject    handle to uipanel_DataSetOptions (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called



function edit_randomSeed_Callback(hObject, eventdata, handles)
% hObject    handle to edit_randomSeed (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_randomSeed as text
%        str2double(get(hObject,'String')) returns contents of edit_randomSeed as a double
user_entry = str2double(get(hObject,'string'));
if isnan(user_entry)
  errordlg('You must enter a numeric value','Bad Input','modal')
  uicontrol(hObject)
	return
end

numRandomSeed = get(hObject,'Value')
handles.numRandomSeed = user_entry %numRandomSeed

if handles.dispOnScreen  
    handles
end

% Update handles structure
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit_randomSeed_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_randomSeed (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_numIterations_Callback(hObject, eventdata, handles)
% hObject    handle to edit_numIterations (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_numIterations as text
%        str2double(get(hObject,'String')) returns contents of edit_numIterations as a double
user_entry = str2double(get(hObject,'string'));
if isnan(user_entry)
  errordlg('You must enter a numeric value','Bad Input','modal')
  uicontrol(hObject)
	return
end

%numIterations = get(hObject,'Value')
handles.numIterations = user_entry % numIterations

if handles.dispOnScreen  
    handles
end

% Update handles structure
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edit_numIterations_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_numIterations (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in listbox_ApplyRules.
function listbox5_Callback(hObject, eventdata, handles)
% hObject    handle to listbox_ApplyRules (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox_ApplyRules contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox_ApplyRules


% --- Executes during object creation, after setting all properties.
function listbox5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox_ApplyRules (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in listbox_OriginalDatasetResults.
function listbox_OriginalDatasetResults_Callback(hObject, eventdata, handles)
% hObject    handle to listbox_OriginalDatasetResults (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox_OriginalDatasetResults contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox_OriginalDatasetResults

%%%%%%%%%%%%%%%%%%%%%%INITIAL DATA%%%%%%%%%%%%%%%
handles.HighRep = 2;
handles.RegRep = 0.5; 

handles.ResultData=0;

handles.AggRules = 0 ;

%%%%%%%%%%%%%%%%%%%%%%INITIAL DATA ENDS %%%%%%%%%%%%%%%

valResultData = get(hObject, 'Value');
strResultData = get(hObject, 'String');
handles.ResultData = valResultData ;

if handles.dispOnScreen  
    handles
end

% Update handles structure
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function listbox_OriginalDatasetResults_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox_OriginalDatasetResults (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in listbox_BootstrapResults.
function listbox_BootstrapResults_Callback(hObject, eventdata, handles)
% hObject    handle to listbox_BootstrapResults (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox_BootstrapResults contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox_BootstrapResults
%%%%%%%%%%%%%%%%%%%%%%INITIAL DATA%%%%%%%%%%%%%%%
handles.HighRep = 2;
handles.RegRep = 0.5; 

handles.ResultData=0;

handles.AggRules = 0 ;
%%%%%%%%%%%%%%%%%%%%%%INITIAL DATA ENDS %%%%%%%%%%%%%%%

valAggRules = get(hObject, 'Value');
strAggRules = get(hObject, 'String');
handles.AggRules = valAggRules ;

% Update handles structure
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function listbox_BootstrapResults_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox_BootstrapResults (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function ord=GetSocOrder(a,id);
n=(1+sqrt(1+4*size(a,2)))/2;

switch id
    case 1 %Major Rule
        ord=MajorityRule3(a);
    case 2 % Borda Rule
        ord=BordaRule2(a);
        ord=ToGeneralizedRankMatrix(VotesToBinaryRelationship(ord));
    case 3 % Plurality
        qtemp=AmountInRows(a);
        ord=VotesToRankings(qtemp'*(ToGeneralizedRankMatrix(a)==1),n+1-(1:n));
        ord=ToGeneralizedRankMatrix(VotesToBinaryRelationship(ord));
    case 4 %%Anti Plur
        qtemp=AmountInRows(a);
        ord=VotesToRankings(qtemp'*(ToGeneralizedRankMatrix(a)==n),1:n);
        ord=ToGeneralizedRankMatrix(VotesToBinaryRelationship(ord));
    case 5 % STV Rule use STVOrder for multiseat (5 candidates in input). order ranking is sequence of
    % candidates that are added when number of seats increases
        ord=STVOrder(a); 
        
    case 6 % Coombs - use CoombsOrder for multiseat. order ranking is sequence of
    % candidates that are added when number of seats increases
        ord=CoombsOrder(a); 
    case 7 % Plurality Runoff
        ord=PluralityRunoffRule(a);
    case 8 % Alternative Vote
        ord=STVRule(a,1);
        ord=n-(n-1)*(ord==max(ord));
    case 9 % Random
        ord=RandomRule(a);    
        ord=ToGeneralizedRankMatrix(VotesToBinaryRelationship(ord));
    case 10 % Generalized Rank Mean
        ord=GRMeanRule(a);
        ord=ToGeneralizedRankMatrix(VotesToBinaryRelationship(ord));
    case 11 % Generalized Rank Median
        ord=GRMedianRule(a);
        ord=ToGeneralizedRankMatrix(VotesToBinaryRelationship(ord));
    case 12 % Generalized Rank Mode
        ord=GRModeRule(a);
        ord=ToGeneralizedRankMatrix(VotesToBinaryRelationship(ord));
    case 13 % Mode
        ord=ModeRule(a);
        ord=ToGeneralizedRankMatrix(VotesToBinaryRelationship(ord));
    %case 10 % Copeland
    %    ord=CopelandRule(a);
    %
    %    case 14% Inverse Borda
    %    ord=RandomRule(a); %ord=InverseBordaRule(a);
    end;
    

    
function handles=SaveResults(report_name,Results,Rules,Params,handles);
    text=get(handles.listbox_OriginalDatasetResults,'String');
    text=char(text,report_name);
    if handles.TotalResults==1;
        set(handles.listbox_OriginalDatasetResults,'String',report_name);
    else;
        set(handles.listbox_OriginalDatasetResults,'String',text);
    end;
    savefile=['res' num2str(handles.TotalResults) '.res'];
    save(savefile,'Results','Rules','Params');
    
function handles=ProcessData(data,handles);
    Rules=handles.Rules(find(handles.Rules>1));
    Results=zeros(handles.numIterations,handles.numCandidates,size(Rules,2));
    if get(handles.radiobutton_FileUploadCSV,'Value')==1; %loading data from file
        for j=1:size(Rules,2);
           Results(1,:,j)=GetSocOrder(data,Rules(j)-1);
        end;
    end;
    RandStream.setDefaultStream(RandStream('mt19937ar','Seed',handles.numRandomSeed));
    h = waitbar(0,'Proceeding with bootstrap, please wait...');
    q=AmountInRows(data);
    start=1+1*get(handles.radiobutton_FileUploadCSV,'Value');
    for i=start:handles.numIterations;
%        a=sign(data(generate_pseudosample(q,handles.numVoters),:));
        a=sign(data(generate_pseudosample(handles.data(:,size(handles.data,2)),handles.numVoters),:));
        a=summarizeBallots(a);
        a=a(:,1:(size(a,2)-1)).*kron(ones(1,(size(a,2)-1)),a(:,size(a,2)));
        for j=1:size(Rules,2);
                   Results(i,:,j)=GetSocOrder(a,Rules(j)-1);
        end;
        waitbar(i/handles.numIterations);
    end;
    close(h);
    handles.TotalResults=handles.TotalResults+1;
    Params.filename=handles.fileName;
    Params.date=now;
    Params.type=handles.Params;
    Params.voters=handles.numVoters;
    Params.cand=handles.numCandidates;
    handles=SaveResults(['Result ',num2str(handles.TotalResults)],Results,Rules,Params,handles);
    clear('Results','Rules');

function handles=ProcessDataSIM(data,handles);
    Rules=handles.Rules(find(handles.Rules>1));
    Results=zeros(handles.numIterations,handles.numCandidates,size(Rules,2));
    if get(handles.radiobutton_FileUploadCSV,'Value')==1; %loading data from file
        All=OriginalToAll(data,'WO');
        for j=1:size(Rules,2);
           Results(1,:,j)=GetSocOrder(All,Rules(j)-1);
        end;
    end;
    RandStream.setDefaultStream(RandStream('mt19937ar','Seed',handles.numRandomSeed));
    h = waitbar(0,'Proceeding with bootstrap, please wait...');
    n=handles.numCandidates;
    q=data(:,n+1);
    start=1+1*get(handles.radiobutton_FileUploadCSV,'Value');
    F=prod(1:n);
    p=[];
    for i=1:(n-1);
        p(i)=sum((max(data(:,1:n)')==i)'.*q);
    end;
    p0=p'/sum(q);
    p=(ones(1,F-1)')/F;
    options = optimset('Display','off');  % Turn off display
   % disp([F,size(p,1),size(p,2),size(p0,1),size(p0,2)]);
    p=fminsearch(@(t) -LogLikelihood(data,[t;p0]),p,options);
    p=[p;p0];
    for i=start:handles.numIterations;
        a=ParametricBootstrap2(handles.numVoters,p,n);
        a=OriginalToAll(a,'WO');
        for j=1:size(Rules,2);
                   Results(i,:,j)=GetSocOrder(a,Rules(j)-1);
        end;
        waitbar(i/handles.numIterations);
    end;
    close(h);
    handles.TotalResults=handles.TotalResults+1;
    Params.filename=handles.fileName;
    Params.date=now;
    Params.type=handles.Params;
    Params.voters=handles.numVoters;
    Params.cand=handles.numCandidates;
    handles=SaveResults(['Result ',num2str(handles.TotalResults)],Results,Rules,Params,handles);
    clear('Results','Rules');
    
function handles=ProcessDataIAC(p0,handles,type);
    Rules=handles.Rules(find(handles.Rules>1));
    Results=zeros(handles.numIterations,handles.numCandidates,size(Rules,2));
    RandStream.setDefaultStream(RandStream('mt19937ar','Seed',handles.numRandomSeed));
    h = waitbar(0,'Proceeding with bootstrap, please wait...');
    n=handles.numCandidates;
    for i=1:handles.numIterations;
        p=-log(rand(prod(1:n),1));
        p=p/sum(p);
        p=p(1:(prod(1:n)-1));
        p=[p;p0];
        a=ParametricBootstrap2(handles.numVoters,p,n);
        a=OriginalToAll(a,type);
        for j=1:size(Rules,2);
                   Results(i,:,j)=GetSocOrder(a,Rules(j)-1);
        end;
        waitbar(i/handles.numIterations);
    end;
    close(h);
    handles.TotalResults=handles.TotalResults+1;
    Params.filename=handles.fileName;
    Params.date=now;
    Params.type=handles.Params;
    Params.voters=handles.numVoters;
    Params.cand=handles.numCandidates;
    handles=SaveResults(['Result ',num2str(handles.TotalResults)],Results,Rules,Params,handles);
    clear('Results','Rules');      
    
  function handles=ProcessDataIC(p0,handles,type);
    Rules=handles.Rules(find(handles.Rules>1));
    Results=zeros(handles.numIterations,handles.numCandidates,size(Rules,2));
    RandStream.setDefaultStream(RandStream('mt19937ar','Seed',handles.numRandomSeed));
    h = waitbar(0,'Proceeding with bootstrap, please wait...');
    n=handles.numCandidates;
    p=ones(prod(1:n),1);
    p=p/sum(p);
    p=p(1:(prod(1:n)-1));
    p=[p;p0];
    for i=1:handles.numIterations;
        a=ParametricBootstrap2(handles.numVoters,p,n);
        a=OriginalToAll(a,type);
        for j=1:size(Rules,2);
                   Results(i,:,j)=GetSocOrder(a,Rules(j)-1);
        end;
        waitbar(i/handles.numIterations);
    end;
    close(h);
    handles.TotalResults=handles.TotalResults+1;
    Params.filename=handles.fileName;
    Params.date=now;
    Params.type=handles.Params;
    Params.voters=handles.numVoters;
    Params.cand=handles.numCandidates;
    handles=SaveResults(['Result ',num2str(handles.TotalResults)],Results,Rules,Params,handles);
    clear('Results','Rules');      
    
% --- Executes on button press in pushbutton_StartAnalysis.
function pushbutton_StartAnalysis_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_StartAnalysis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



%%%%%%%%%%%%%%%%%%%%%%INITIAL DATA%%%%%%%%%%%%%%%
handles.HighRep = 2;
handles.RegRep = 0.5; 
handles.numVoters = str2num(get(handles.edit_numVoters,'String'));

handles.ResultData=0;

handles.AggRules = 0 ;
%%%%%%%%%%%%%%%%%%%%%%INITIAL DATA ENDS %%%%%%%%%%%%%%%


set(handles.listbox_OriginalDatasetResults,'Enable','on')
set(handles.pushbutton_ResultTable,'Enable','on')
%set(handles.pushbutton_ExportResults,'Enable','on')

set(handles.radiobutton_FileUploadCSV,'Enable','off');
set(handles.radiobutton_FileUploadSIM,'Enable','off');
set(handles.text_FileUploadSIM,'Enable','off');

set(handles.pushbutton_FileChooser,'Enable','off');
set(handles.edit_FileLocation,'Enable','inactive');
set(handles.text_FileLocation,'Enable','on');
set(handles.edit_numCandidates,'Enable','inactive');
set(handles.text_numCandidates,'Enable','on');
set(handles.edit_numVoters,'Enable','inactive');
set(handles.text_numVoters,'Enable','on');
set(handles.edit_numVotersInData,'Enable','inactive');
set(handles.text_numVotersInData,'Enable','on');

set(handles.text_DataChoices,'Enable','off');
set(handles.popupmenu_DataType,'Enable','off');   
set(handles.listbox_RankedData,'Enable','off');
set(handles.listbox_PartialData,'Enable','off');

set(handles.text_CultType,'Enable','off')
set(handles.popupmenu_CultType,'Enable','off');
set(handles.listbox_CultRankedData,'Enable','off');
set(handles.listbox_CultPartialData,'Enable','off');

set(handles.listbox_ApplyRules,'Enable','off');
set(handles.text_numIterations,'Enable','off');
set(handles.edit_numIterations,'Enable','off');
set(handles.text_numVoters,'Enable','off');
 set(handles.edit_numVoters,'Enable','off');
set(handles.text_randomSeed,'Enable','off');
set(handles.edit_randomSeed,'Enable','off');

%% SERGEY START


if get(handles.radiobutton_FileUploadCSV,'Value')==1; % data file
    if (handles.DataType==2); 
        data=handles.data;
        handles.Params='From file; Binary.';
        handles=ProcessData(data,handles);    
    elseif (handles.DataType==3);
        if get(handles.listbox_RankedData,'Value')==2;
            %full ranking
            data=OriginalToAll(handles.data,'WO');
            handles.Params='From file; ranked data; full rank.';
            handles=ProcessData(data,handles); 
        elseif get(handles.listbox_RankedData,'Value')==3;
            if get(handles.listbox_PartialData,'Value')==2;
                % Zwicker
                data=OriginalToAll(handles.data,'ZW');
                handles.Params='From file; ranked data; partial ranking; Partial Order.';
                handles=ProcessData(data,handles); 
            elseif get(handles.listbox_PartialData,'Value')==3;
                % WO
                data=OriginalToAll(handles.data,'WO');
                handles.Params='From file; ranked data; partial ranking; Weak order.';
                handles=ProcessData(data,handles); 
            elseif get(handles.listbox_PartialData,'Value')==4;
                % SIM
                data=handles.data;
                handles.Params='From file; ranked data; partial ranking; SIM model.';
                handles=ProcessDataSIM(data,handles); 
            else;
                %do nothing
            end;
        else;
            %neither full ranking or partial ranking is chosen
        end;    
   elseif (handles.DataType==4)&(get(handles.RatingTreatMissing,'Value')>0);
         if get(handles.RatingTreatMissing,'Value')==2;
            data=RatingToAll(handles.data,str2double(get(handles.BestRating,'String')),str2double(get(handles.WorstRating,'String')),str2double(get(handles.RatingThreshold,'String')),0);
            handles.Params=['From file; rating data; span is from ', get(handles.WorstRating,'String'), ' (worst) to ', get(handles.BestRating,'String') ' (best), threshold is ', get(handles.RatingThreshold,'String'), ', ']; 
            handles.Params=[handles.Params, 'Partial Order model.'];
            handles=ProcessData(data,handles); 
         elseif get(handles.RatingTreatMissing,'Value')==3;
            data=RatingToAll(handles.data,str2double(get(handles.BestRating,'String')),str2double(get(handles.WorstRating,'String')),str2double(get(handles.RatingThreshold,'String')),1);
            handles.Params=['From file; rating data; span is from ', get(handles.WorstRating,'String'), ' (worst) to ', get(handles.BestRating,'String') ' (best), threshold is ', get(handles.RatingThreshold,'String'), ', '];
            handles.Params=[handles.Params, 'Weak Order model.'];
            handles=ProcessData(data,handles); 
         elseif get(handles.RatingTreatMissing,'Value')==4;
            data=handles.data;
            data(find(isnan(data)))=handles.RatingReplaceWith;
            data=RatingToAll(data,str2double(get(handles.BestRating,'String')),str2double(get(handles.WorstRating,'String')),str2double(get(handles.RatingThreshold,'String')),1);
            handles.Params=['From file; rating data; span is from ', get(handles.WorstRating,'String'), ' (worst) to ', get(handles.BestRating,'String') ' (best), threshold is ', get(handles.RatingThreshold,'String'), ', '];
            handles.Params=[handles.Params, 'Replaced NaNs with ', num2str(handles.RatingReplaceWith)];
            handles=ProcessData(data,handles); 
         end;
         
         
  end;
else; % generated culture: IC or IAC 
    
    if (handles.CultDataType==2); % IC or ELP
        if (handles.CultRankedData==2);
            handles.Params='Impartial Culture; full ranking';
            p0=[zeros(1,handles.numCandidates-1)'];
            handles=ProcessDataIC(p0,handles,'WO'); 
        else;
            if handles.CultPartialData == 2; %zwicker order is chosen for IC
                handles.Params='Impartial Culture; partial ranking; Partial Order';
                p0=[ones(1,handles.numCandidates-1)'/handles.numCandidates];
                handles=ProcessDataIC(p0,handles,'ZW'); 
            elseif handles.CultPartialData==4;
                % SIM
                handles.Params='Impartial Culture; partial ranking; SIM model.';
                p0=[ones(1,handles.numCandidates-1)'/handles.numCandidates];
                handles=ProcessDataIC(p0,handles,'WO');
            else; %weak order is chosen for IC
                handles.Params='Impartial Culture; partial ranking; Weak Order';
                p0=[ones(1,handles.numCandidates-1)'/handles.numCandidates];
                handles=ProcessDataIC(p0,handles,'WO'); 
            end;
            
        end;
    elseif (handles.CultDataType==3); % IAC or ELAP
         if (handles.CultRankedData==2);
            handles.Params='Impartial Anonymous Culture; full ranking';
            p0=[zeros(1,handles.numCandidates-1)'];
            handles=ProcessDataIAC(p0,handles,'WO'); 
        else;
        
            if handles.CultPartialData == 2; %zwicker order is chosen for IC
                handles.Params='Impartial Anonymous Culture; partial ranking; Partial Order';
                p0=[ones(1,handles.numCandidates-1)'/handles.numCandidates];
                handles=ProcessDataIAC(p0,handles,'ZW'); 
            elseif handles.CultPartialData == 4; %SIM is chosen for IC
                handles.Params='Impartial Anonymous Culture; partial ranking; SIM model';
                p0=[ones(1,handles.numCandidates-1)'/handles.numCandidates];
                handles=ProcessDataIAC(p0,handles,'WO'); 
            else; %weak order is chosen for IC
                handles.Params='Impartial Anonymous Culture; partial ranking; Weak Order';
                p0=[ones(1,handles.numCandidates-1)'/handles.numCandidates];
                handles=ProcessDataIAC(p0,handles,'WO'); 
            end;
            
        end;
    end;
end;

%% SERGEY END

set(handles.radiobutton_FileUploadCSV,'Enable','on');
set(handles.radiobutton_FileUploadSIM,'Enable','on');
set(handles.text_FileUploadSIM,'Enable','on');

set(handles.pushbutton_FileChooser,'Enable','on');
set(handles.edit_FileLocation,'Enable','on');
set(handles.text_FileLocation,'Enable','on');
set(handles.edit_numCandidates,'Enable','inactive');
set(handles.text_numCandidates,'Enable','on');
set(handles.edit_numVoters,'Enable','on');
set(handles.text_numVoters,'Enable','on');
set(handles.edit_numVotersInData,'Enable','inactive');
set(handles.text_numVotersInData,'Enable','on');

set(handles.text_DataChoices,'Enable','on');
set(handles.popupmenu_DataType,'Enable','on');   
set(handles.listbox_RankedData,'Enable','on');
set(handles.listbox_PartialData,'Enable','on');

set(handles.text_CultType,'Enable','on')
set(handles.popupmenu_CultType,'Enable','on');
set(handles.listbox_CultRankedData,'Enable','on');
set(handles.listbox_CultPartialData,'Enable','on');

set(handles.listbox_ApplyRules,'Enable','on');
set(handles.text_numIterations,'Enable','on');
set(handles.edit_numIterations,'Enable','on');
set(handles.text_numVoters,'Enable','on');
set(handles.edit_numVoters,'Enable','on');
set(handles.text_randomSeed,'Enable','on');
set(handles.edit_randomSeed,'Enable','on');

% results handling
    set(handles.listbox_OriginalDatasetResults,'Enable','on')
    set(handles.pushbutton_ResultTable,'Enable','on')
    %set(handles.pushbutton_ExportResults,'Enable','on')
    %set(handles.radiobutton_HighRep,'Value',1);   
   set(handles.listbox_BootstrapResults, 'Enable','on');
   set(handles.pushbutton_AgreementTable, 'Enable','on');
   %set(handles.radiobutton_HighRep,'Enable','on');
   %set(handles.text_HighRep,'Enable','on');
   %set(handles.edit_HighRep,'Enable','on');
   %set(handles.radiobutton_RegRep,'Enable','on');
   %set(handles.text_RegRep,'Enable','on');
   %set(handles.edit_RegRep,'Enable','off');
   %set(handles.pushbutton_Bootstrap_Data,'Enable','on');


%f = figure('Position',[100 100 400 150]);
%columnname =   {'Options', 'Analysis Name', 'Available', 'Date Analyzed'};
%columnformat = {'char', 'char', 'logical', {'Fixed' 'Adjustable'}};
%columneditable =  [false true true false]; 


% set(handles.listbox_OriginalDatasetResults,'String',resultSTRINGMatrix);

%t = uitable('Units','normalized','Position',...
%            [0.1 0.1 0.9 0.9], 'Data', resultSTRINGMatrix',... 
%            'ColumnName', columnname,...
%            'ColumnFormat', columnformat,...
%            'ColumnEditable', columneditable,...
%            'RowName',[],...
%            'HitTest','on');



% Update handles structure
guidata(hObject, handles);


% --- Executes on selection change in popupmenu_CultType.
function popupmenu_CultType_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu_CultType (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu_CultType contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu_CultType

%%%%%%%%%%%%%%%%%%%%%%INITIAL DATA%%%%%%%%%%%%%%%
handles.data = '';
handles.fileName= '';

handles.DataType = 0;
handles.RankedData = 0;

handles.PartialData = 0;

handles.CultDataType = 0;
handles.CultRankedData = 0;
handles.CultPartialData = 0;

handles.isactiveRulesToApply = 0;

handles.Rules = 0;
handles.HighRep = 2;
handles.RegRep = 0.5; 

handles.ResultData=0;

handles.AggRules = 0 ;
set(handles.listbox_CultRankedData,'Visible','off'); 
set(handles.listbox_CultRankedData,'Value',1); 
set(handles.listbox_CultPartialData,'Visible','off');
set(handles.listbox_CultPartialData,'Value',1);
%%%%%%%%%%%%%%%%%%%%%%INITIAL DATA ENDS %%%%%%%%%%%%%%%


valCultDataType = get(hObject, 'Value');
handles.CultDataType = valCultDataType;

switch valCultDataType 
    case 1 %Selection Other Data Title
        msgbox('You need to choose Culture Type!','Error','modal');
        set(handles.listbox_CultRankedData,'Enable','off'); 
        set(handles.listbox_CultPartialData,'Enable','off');
        set(handles.listbox_CultRankedData,'Visible','off'); 
        set(handles.listbox_CultPartialData,'Visible','off');
        set(handles.listbox_ApplyRules,'Enable','off');
        set(handles.text_numIterations,'Enable','off');
        set(handles.edit_numIterations,'Enable','off');
        set(handles.text_numVoters,'Enable','off');
        set(handles.edit_numVoters,'Enable','off');
        set(handles.text_randomSeed,'Enable','off');
        set(handles.edit_randomSeed,'Enable','off');
        set(handles.pushbutton_StartAnalysis,'Enable','off');
        return;
    case 2 %Selection Impartial Culture (IC)
        set(handles.listbox_CultRankedData,'Visible','on'); 
        set(handles.listbox_CultRankedData,'Enable','on');
        set(handles.listbox_CultPartialData,'Enable','off');
        set(handles.listbox_ApplyRules,'Enable','off');
        set(handles.text_numIterations,'Enable','off');
        set(handles.edit_numIterations,'Enable','off');
        set(handles.text_numVoters,'Enable','off');
        set(handles.edit_numVoters,'Enable','off');
        set(handles.text_randomSeed,'Enable','off');
        set(handles.edit_randomSeed,'Enable','off');
        set(handles.pushbutton_StartAnalysis,'Enable','off');
    case 3 %Selection Impartial Anonymous Culture (IAC)
        set(handles.listbox_CultRankedData,'Enable','on');
        set(handles.listbox_CultRankedData,'Visible','on'); 
        set(handles.listbox_CultPartialData,'Enable','off');
        set(handles.listbox_ApplyRules,'Enable','off');
        set(handles.text_numIterations,'Enable','off');
        set(handles.edit_numIterations,'Enable','off');
        set(handles.text_numVoters,'Enable','off');
        set(handles.edit_numVoters,'Enable','off');
        set(handles.text_randomSeed,'Enable','off');
        set(handles.edit_randomSeed,'Enable','off');
        set(handles.pushbutton_StartAnalysis,'Enable','off');
end 

handles.isactiveRulesToApply = 0;

if handles.dispOnScreen  
    handles
end

% Update handles structure
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function popupmenu_CultType_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu_CultType (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in listbox_CultRankedData.
function listbox_CultRankedData_Callback(hObject, eventdata, handles)
% hObject    handle to listbox_CultRankedData (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox_CultRankedData contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox_CultRankedData

%%%%%%%%%%%%%%%%%%%%%%INITIAL DATA%%%%%%%%%%%%%%%
handles.data = '';
handles.fileName= '';

handles.DataType = 0;
handles.RankedData = 0;
handles.PartialData = 0;

handles.CultRankedData = 0;
handles.CultPartialData = 0;

handles.isactiveRulesToApply = 0;

handles.Rules = 0;
handles.HighRep = 2;
handles.RegRep = 0.5; 

handles.ResultData=0;

handles.AggRules = 0 ;

set(handles.listbox_CultPartialData,'Visible','off');

%%%%%%%%%%%%%%%%%%%%%%INITIAL DATA ENDS %%%%%%%%%%%%%%%

valCultRankedData = get(hObject, 'Value');
strCultRankedData = get(hObject, 'String');
handles.CultRankedData = valCultRankedData;

if valCultRankedData==1 
    msgbox('Please choose Ranking!','Error','modal');
    set(handles.listbox_CultPartialData,'Enable','off');
    set(handles.listbox_CultPartialData,'Visible','off');
    set(handles.listbox_ApplyRules,'Enable','off');
    set(handles.text_numIterations,'Enable','off');
    set(handles.edit_numIterations,'Enable','off');
    set(handles.text_numVoters,'Enable','off');
    set(handles.edit_numVoters,'Enable','off');
    set(handles.text_randomSeed,'Enable','off');
    set(handles.edit_randomSeed,'Enable','off');
    return
elseif valCultRankedData==3 
    set(handles.listbox_CultPartialData,'Enable','on');
    set(handles.listbox_CultPartialData,'Visible','on');
    set(handles.listbox_CultPartialData,'Value',1);
    set(handles.listbox_ApplyRules,'Enable','off');
    set(handles.text_numIterations,'Enable','off');
    set(handles.edit_numIterations,'Enable','off');
    set(handles.text_numVoters,'Enable','off');
    set(handles.edit_numVoters,'Enable','off');
    set(handles.text_randomSeed,'Enable','off');
    set(handles.edit_randomSeed,'Enable','off');
elseif valCultRankedData == 4 
    msgbox('Option Coming Soon','Error','modal');
    set(handles.listbox_CultPartialData,'Enable','off'); 
    set(handles.listbox_CultPartialData,'Visible','off');
    set(handles.listbox_ApplyRules,'Enable','off');
    set(handles.text_numIterations,'Enable','off');
    set(handles.edit_numIterations,'Enable','off');
    set(handles.text_numVoters,'Enable','off');
    set(handles.edit_numVoters,'Enable','off');
    set(handles.text_randomSeed,'Enable','off');
    set(handles.edit_randomSeed,'Enable','off');
    return
else
    set(handles.listbox_CultPartialData,'Enable','off');
    set(handles.listbox_ApplyRules,'Enable','on');
    set(handles.text_numIterations,'Enable','off');
    set(handles.edit_numIterations,'Enable','off');
    set(handles.text_numVoters,'Enable','off');
    set(handles.edit_numVoters,'Enable','off');
    set(handles.text_randomSeed,'Enable','off');
    set(handles.edit_randomSeed,'Enable','off');
end 

handles.isactiveRulesToApply = 0;

if handles.dispOnScreen  
    handles
end

% Update handles structure
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function listbox_CultRankedData_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox_CultRankedData (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in listbox_CultPartialData.
function listbox_CultPartialData_Callback(hObject, eventdata, handles)
% hObject    handle to listbox_CultPartialData (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox_CultPartialData contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox_CultPartialData
%%%%%%%%%%%%%%%%%%%%%%INITIAL DATA%%%%%%%%%%%%%%%
handles.data = '';
handles.fileName= '';

handles.DataType = 0;
handles.RankedData = 0;
handles.PartialData = 0;

handles.CultPartialData = 0;

handles.isactiveRulesToApply = 0;

handles.Rules = 0;
handles.HighRep = 2;
handles.RegRep = 0.5; 

handles.ResultData=0;

handles.AggRules = 0 ;
%%%%%%%%%%%%%%%%%%%%%%INITIAL DATA ENDS %%%%%%%%%%%%%%%


valCultPartialData = get(hObject, 'Value');
strCultPartialData = get(hObject, 'String');
handles.CultPartialData = valCultPartialData;


if ~isempty(find(valCultPartialData == 1)) 
    msgbox('Please choose Partial Ranking Model!','Error','modal');
    set(handles.listbox_ApplyRules,'Enable','off');
    set(handles.text_numIterations,'Enable','off');
    set(handles.edit_numIterations,'Enable','off');
    set(handles.text_numVoters,'Enable','off');
    set(handles.edit_numVoters,'Enable','off');
    set(handles.text_randomSeed,'Enable','off');
    set(handles.edit_randomSeed,'Enable','off');
    return
elseif ~isempty(find(valCultPartialData == 5)) 
    msgbox('Option "Others" is coming soon, please correct your choice','Error','modal');
    set(handles.listbox_ApplyRules,'Enable','off');
    set(handles.text_numIterations,'Enable','off');
    set(handles.edit_numIterations,'Enable','off');
    set(handles.text_numVoters,'Enable','off');
    set(handles.edit_numVoters,'Enable','off');
    set(handles.text_randomSeed,'Enable','off');
    set(handles.edit_randomSeed,'Enable','off');
    return
elseif ~isempty(find(valCultPartialData == 2)) || ~isempty(find(valCultPartialData == 3)) || ~isempty(find(valCultPartialData == 4))
    set(handles.listbox_ApplyRules,'Enable','on');
    set(handles.text_numIterations,'Enable','off');
    set(handles.edit_numIterations,'Enable','off');
    set(handles.text_numVoters,'Enable','off');
    set(handles.edit_numVoters,'Enable','off');
    set(handles.text_randomSeed,'Enable','off');
    set(handles.edit_randomSeed,'Enable','off');
else 
    set(handles.listbox_ApplyRules,'Enable','off');
    set(handles.text_numIterations,'Enable','off');
    set(handles.edit_numIterations,'Enable','off');
    set(handles.text_numVoters,'Enable','off');
    set(handles.edit_numVoters,'Enable','off');
    set(handles.text_randomSeed,'Enable','off');
    set(handles.edit_randomSeed,'Enable','off');
end

handles.isactiveRulesToApply = 0;

if handles.dispOnScreen  
    handles
end

% Update handles structure
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function listbox_CultPartialData_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox_CultPartialData (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton_ResultTable.
function pushbutton_ResultTable_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_ResultTable (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[Results,Rules,Params]=LoadCurrentResult(handles);

text={['Filename: ' Params.filename '.']};
text=[text; {  ['Date: ' datestr(Params.date) '.']}];
text=[text; {  Params.type}];
text=[text; {  [num2str(Params.voters) ' voters, '  num2str(Params.cand) ' candidates, ' num2str(size(Results,1)) ' bootstrap iterations.']}];

msgbox(text, 'Selected Result')

clear Results Rules Params;

%f = figure('Position',[200 200 400 150]);
%dat = rand(3); 
%cnames = {'X-Data','Y-Data','Z-Data'};
%rnames = {'First','Second','Third'};
%t = uitable('Parent',f,'Data',dat,'ColumnName',cnames,... 
%            'RowName',rnames,'Position',[20 20 300 100]);
        
% f = figure('Position',[100 100 400 150]);
% dat =  {6.125, 456.3457, true,  'Fixed';...
%         6.75,  510.2342, false, 'Adjustable';...   
%         7,     658.2,    false, 'Fixed';};
% columnname =   {'Rate', 'Amount', 'Available', 'Fixed/Adj'};
% columnformat = {'numeric', 'bank', 'logical', {'Fixed' 'Adjustable'}};
% columneditable =  [false false true true]; 

% t = uitable('Units','normalized','Position',...
%             [0.1 0.1 0.9 0.9], 'Data', dat,... 
%             'ColumnName', columnname,...
%             'ColumnFormat', columnformat,...
%             'ColumnEditable', columneditable,...
%             'RowName',[]);

if handles.dispOnScreen  
    handles
end

% Update handles structure
guidata(hObject, handles);

% --- Executes on button press in pushbutton_ExportResults.
% function pushbutton_ExportResults_Callback(hObject, eventdata, handles)
% % hObject    handle to pushbutton_ExportResults (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% 
% if ~(get(handles.listbox_OriginalDatasetResults,'Value')>0);
%     return;
% end;
% if ~(get(handles.listbox_OriginalDatasetResults,'Value')>0);
%     return;
% end;
% [filename, pathname] = uiputfile('*.csv', 'Save a .csv file with results');
% if isequal(filename,0)
%    disp('User selected Cancel');
%    return
% else
%    disp(['User selected ', fullfile(pathname, filename)])
% end
% [Results,Rules,Params]=LoadCurrentResult(handles);
% q=[];
% for i=1:size(Results,3);
%     q=[q; [ones(size(Results,1),1)*Rules(i) Results(:,:,i)]];
% end;
% dlmwrite(fullfile(pathname, filename), M, ',');
% clear q filename pathname Results Rules Params;
% 

% Update handles structure

function edit_HighRep_Callback(hObject, eventdata, handles)
% hObject    handle to edit_HighRep (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_HighRep as text
%        str2double(get(hObject,'String')) returns contents of edit_HighRep as a double
minHighRep = 1;
maxHighRep = handles.numIterations;

strHighRep = get(hObject,'String') 
valHighRep = num2str(strHighRep);
if valHighRep < minHighRep || valHighRep > maxHighRep
    msgbox(['Number of Orders should be between ' num2str(minHighRep) ' and ' ...
            num2str(maxHighRep)],'Error','modal');
    return;
elseif (floor(valHighRep) - valHighRep) ~= 0
    disp('Incorrect number of Orders: Please check your input file!')
        return
end 

set(handles.edit_numHighRep,'string',valHighRep);

handles.HighRep = valHighRep;

% Update handles structure
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit_HighRep_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_HighRep (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_RegRep_Callback(hObject, eventdata, handles)
% hObject    handle to edit_RegRep (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_RegRep as text
%        str2double(get(hObject,'String')) returns contents of edit_RegRep as a double
minRegRep = 0;
maxRegRep = 1;

strRegRep= get(hObject,'String'); 
valRegRep= num2str(strRegRep);
if valRegRep < minRegRep || valRegRep > maxRegRep
    msgbox(['Replicability Cutoff should be between ' num2str(minRegRep) ' and ' ...
            num2str(maxRegRep)],'Error','modal');
    return;
end 
set(handles.edit_numRegRep,'string',valRegRep);

handles.RegRep=valRegRep;

if handles.dispOnScreen  
    handles
end

% Update handles structure
guidata(hObject, handles); 

% --- Executes during object creation, after setting all properties.
function edit_RegRep_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_RegRep (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
% Update handles structure
guidata(hObject, handles); 

function [Results,Rules,Params]=LoadCurrentResult(handles);
i=get(handles.listbox_OriginalDatasetResults,'Value');
loadfile=['res' num2str(i) '.res'];
load(loadfile,'-mat','Results','Rules','Params')

% --- Executes on button press in pushbutton_AgreementTable.
function pushbutton_AgreementTable_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_AgreementTable (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if get(handles.listbox_BootstrapResults,'Value')==1;
    return;
end;

[Results,Rules,Params]=LoadCurrentResult(handles);

matsize=size(Results,3);
rulenames=get(handles.listbox_ApplyRules,'String');

switch get(handles.listbox_BootstrapResults,'Value')
    case 2 % first rank agreement
        dat=cell(matsize,matsize);
        for i=1:matsize;
            for j=1:matsize;
                  if i==j;
                      dat{i,j}=mean(sum((Results(:,:,i)==1)')'==1);
                  else; 
                      dat{i,j}=ProbThatWinnersAreSame(Results(:,:,i),Results(:,:,j));
                  end;
            end;
        end;
        cnames=rulenames(Rules);
        rnames=rulenames(Rules);
    case 3 % last rank agreement
        dat=zeros(matsize,matsize);
        for i=1:matsize;
            for j=1:matsize;
                if i==j;
                    dat(i,j)=mean(sum((Results(:,:,i)==size(Results,2))')'==1);
                else; 
                    dat(i,j)=ProbThatLosersAreSame(Results(:,:,i),Results(:,:,j));
                end;
            end;
        end;
        cnames=rulenames(Rules);
        rnames=rulenames(Rules);
    case 4 % Orders agreement
        dat=zeros(matsize,matsize);
        for i=1:matsize;
            for j=1:matsize;
                if i==j;
                    dat(i,j)=mean(max(abs(sort(Results(:,:,i)')'-kron(ones(size(Results,1),1),1:size(Results,2)))')==0);
                else; 
                    dat(i,j)=ProbThatOrdersAreSame(Results(:,:,i),Results(:,:,j));
                end;
            end;
        end;
        cnames=rulenames(Rules);
        rnames=rulenames(Rules);
    case 5 % First Rank is Last Rank
        dat=zeros(matsize,matsize);
        for i=1:matsize;
            for j=1:matsize;
               dat(i,j)=ProbThatWinnerChooseLoser(Results(:,:,i),Results(:,:,j));
            end;
        end;
        cnames=rulenames(Rules);
        rnames=rulenames(Rules);
    case 6 % First Rank is Last Rank Frequencies
        dat=zeros(matsize,matsize);
        for i=1:matsize;
            for j=1:matsize;
                dat(i,j)=ProbThatWinnerChooseLoserFreq(Results(:,:,i),Results(:,:,j));    
            end;
        end;
        cnames=rulenames(Rules);
        rnames=rulenames(Rules);
    case 7 % First Rank Replicability
        dat=cell(matsize,size(Results,2)+1);
        cnames={};
        for j=1:size(Results,2);
            cnames=[cnames {char(64+j)}];
            for i=1:matsize;
                temp=Results(:,:,i);
                temp(find(temp==0))=size(temp,2);
                temp=ToGeneralizedRankMatrix(OriginalToAll([size(temp,2)+1-temp ones(size(temp,1),1)]));
                temp=temp==size(Results,2)*ones(size(temp,1),size(temp,2));
                dat{i,j}=mean((sum(temp')'==1).*temp(:,j));    
                if j==1;
                    dat{i,size(Results,2)+1}=1-dat{i,j};
                else;
                    dat{i,size(Results,2)+1}=dat{i,size(Results,2)+1}-dat{i,j};
                end;
            end;
        end;
        dat=[cell(matsize,1) dat];
        for i=1:matsize;
            temp=Results(1,:,i);
            temp(find(temp==0))=size(Results,2);
            temp=OrderToLetters(temp);
            if (size(temp,2)>1)&&(temp(2)=='>');
                dat{i,1}=temp(1);
            else;
                dat{i,1}='*';
            end;
            dat{i,size(Results,2)+2}=round(dat{i,size(Results,2)+2}*10000)/10000;
        end;
        cnames=['First rank Candidate' cnames 'No First Rank'];
        rnames=rulenames(Rules);
    case 8 % Last Rank Replicability
        dat=cell(matsize,size(Results,2)+1);
        cnames={};
        for j=1:size(Results,2);
            cnames=[cnames {char(64+j)}];
            for i=1:matsize;
                temp=Results(:,:,i);
                temp(find(temp==0))=size(temp,2);
                temp=ToGeneralizedRankMatrix(OriginalToAll([size(temp,2)+1-temp ones(size(temp,1),1)]));
                temp=(temp==(ones(size(temp,1),size(temp,2))));
                dat{i,j}=mean((sum(temp')'==1).*temp(:,j)); 
                if j==1;
                    dat{i,size(Results,2)+1}=1-dat{i,j};
                else;
                    dat{i,size(Results,2)+1}=dat{i,size(Results,2)+1}-dat{i,j};
                end;
            end;
        end;
        dat=[cell(matsize,1) dat];
        for i=1:matsize;
            temp=Results(1,:,i);
            temp(find(temp==0))=size(Results,2);
            temp=OrderToLetters(temp);
            if (size(temp,2)>1)&&(temp(size(temp,2)-1)=='>');
                dat{i,1}=temp(size(temp,2));
            else;
                dat{i,1}='*';
            end;
            dat{i,size(Results,2)+2}=round(dat{i,size(Results,2)+2}*10000)/10000;
        end;
        cnames=['Last rank Candidate' cnames 'No Last Rank'];
        rnames=rulenames(Rules);
    case 9 % Order Replicability
        dat=cell(matsize,2);
        cnames={'Social order' 'Replicability'};
        for i=1:matsize;
             dat{i,2}=mean(sum(abs(Results(:,:,i)-kron(ones(size(Results,1),1),Results(1,:,i)))' )'==0);    
             dat{i,1}=OrderToLetters(Results(1,:,i),Rules(i));    
         end;
        rnames=rulenames(Rules);
end;


names=get(handles.listbox_BootstrapResults,'String');
names=names(get(handles.listbox_BootstrapResults,'Value'));
f = figure('Position',[200 200 600 300],'Resize','off','Name',names{1});
%dat = rand(3); 
%cnames = {'X-Data','Y-Data','Z-Data'};
%rnames = {'First','Second','Third'};
t = uitable('Parent',f,'Data',dat,'ColumnName',cnames,... 
            'RowName',rnames,'Position',[0 0 600 300]); 
% Update handles structure
guidata(hObject, handles);        


% --- Executes when selected object is changed in uipanel_Replicability.
function uipanel_Replicability_SelectionChangeFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in uipanel_Replicability 
% eventdata  structure with the following fields (see UIBUTTONGROUP)
%	EventName: string 'SelectionChanged' (read only)
%	OldValue: handle of the previously selected object or empty if none was selected
%	NewValue: handle of the currently selected object
% handles    structure with handles and user data (see GUIDATA)

%if (hObject == handles.radiobutton_HighRep)
    %set(handles.radiobutton_HighRep,'Value',1);   
%    set(handles.text_HighRep,'Enable','on');
%    set(handles.edit_HighRep,'Enable','on');
%    set(handles.edit_RegRep,'Enable','off');
 
   
   
%elseif(hObject ==handles.radiobutton_RegRep)
%    set(handles.radiobutton_RegRep,'Value',1);   
%    set(handles.text_RegRep,'Enable','on');
%    set(handles.edit_RegRep,'Enable','on');
%    set(handles.edit_HighRep,'Enable','off');
   
%end 
% Update handles structure
guidata(hObject, handles); 


% --- Executes during object creation, after setting all properties.
function uipanel_FileSelection_CreateFcn(hObject, eventdata, handles)
% hObject    handle to uipanel_FileSelection (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Update handles structure
guidata(hObject, handles); 


% --- Executes during object creation, after setting all properties.
function uipanel_Replicability_CreateFcn(hObject, eventdata, handles)
% hObject    handle to uipanel_Replicability (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on button press in pushbutton_Bootstrap_Data.
%function pushbutton_Bootstrap_Data_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_Bootstrap_Data (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%f = figure('Position',[200 200 400 150]);
%dat = rand(3); 
%cnames = {'X-Data','Y-Data','Z-Data'};
%rnames = {'First','Second','Third'};
%t = uitable('Parent',f,'Data',dat,'ColumnName',cnames,... 
 %           'RowName',rnames,'Position',[20 20 360 100]);
% Update handles structure
%guidata(hObject, handles); 


% --- Executes on button press in pushbutton15.
function pushbutton15_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if ~(get(handles.listbox_OriginalDatasetResults,'Value')>0);
    return;
end;
[filename, pathname] = uiputfile('*.mat', 'Save a .mat file with results');
if ~(get(handles.listbox_OriginalDatasetResults,'Value')>0);
    return;
end;
if isequal(filename,0)
   disp('User selected Cancel');
   return
else
   disp(['User selected ', fullfile(pathname, filename)])
end
[Results,Rules,Params]=LoadCurrentResult(handles);
save(fullfile(pathname, filename),'Results','Rules','Params');


%loading results
% --- Executes on button press in pushbutton16.
function pushbutton16_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename, pathname] = uigetfile('*.mat', 'Load a .mat file with results');
if isequal(filename,0)
   disp('User selected Cancel');
   return
else
   disp(['User selected ', fullfile(pathname, filename)])
end
load(fullfile(pathname, filename),'Results','Rules','Params');
    handles.TotalResults=handles.TotalResults+1;
    text=get(handles.listbox_OriginalDatasetResults,'String');
    text=[text; ['Result ' num2str(handles.TotalResults)]];
    set(handles.listbox_OriginalDatasetResults,'String',text)
    savefile=['res' num2str(handles.TotalResults) '.res'];
    save(savefile,'Results','Rules','Params');
    set(handles.listbox_OriginalDatasetResults,'Enable','on')
    set(handles.pushbutton_ResultTable,'Enable','on')
    %set(handles.pushbutton_ExportResults,'Enable','on')
    %set(handles.radiobutton_HighRep,'Value',1);   
   set(handles.listbox_BootstrapResults, 'Enable','on');
   set(handles.pushbutton_AgreementTable, 'Enable','on');
   %set(handles.radiobutton_HighRep,'Enable','on');
   %set(handles.text_HighRep,'Enable','on');
   %set(handles.edit_HighRep,'Enable','on');
   %set(handles.radiobutton_RegRep,'Enable','on');
   %set(handles.text_RegRep,'Enable','on');
   %set(handles.edit_RegRep,'Enable','off');
   %set(handles.pushbutton_Bootstrap_Data,'Enable','on');
guidata(hObject, handles); 


% --- Executes on button press in pushbutton17.
function pushbutton17_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
i=get(handles.listbox_OriginalDatasetResults,'Value');
if ~(i>0);
    return;
end;
prompt={'How would you like to name this result?'};
name='Rename';
numlines=1;
text=cellstr(get(handles.listbox_OriginalDatasetResults,'String'));
defaultanswer=text(i);
answer=inputdlg(prompt,name,numlines,defaultanswer);
text(i)=answer(1);
set(handles.listbox_OriginalDatasetResults,'String',text);
guidata(hObject, handles); 


% --- Executes on button press in pushbutton18.
function pushbutton18_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton18 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

msgbox({'Copyright (c) 2010-2012 Sergey V. Popov and Anna Popova.  All rights reserved.',
    'Quantitative Behavioral Decision Research Laboratory of Prof. Michel Regenwetter', 
    'Department of Psychology, University of Illinois at Urbana-Champaign.',
    'https://sites.google.com/site/sergeyvpopov/papers/social-choice',
    '',
    'A Quantitative Behavioral Framework for Individual and Social Choice,',
    'National Science Foundation, SES # 08-20009 (PI: M. Regenwetter),',
    'awarded by Decision, Risk and Management Science Program.',
    '',
    'MATLAB. (c) 1984-2011 The MathWorks, Inc.'},'About','modal');



function edit_numVotersInData_Callback(hObject, eventdata, handles)
% hObject    handle to edit_numVotersInData (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_numVotersInData as text
%        str2double(get(hObject,'String')) returns contents of edit_numVotersInData as a double


% --- Executes during object creation, after setting all properties.
function edit_numVotersInData_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_numVotersInData (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on key press with focus on listbox_ApplyRules and none of its controls.
function listbox_ApplyRules_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to listbox_ApplyRules (see GCBO)
% eventdata  structure with the following fields (see UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on mouse press over figure background, over a disabled or
% --- inactive control, or over an axes background.
function figure1_WindowButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function BestRating_Callback(hObject, eventdata, handles)
% hObject    handle to BestRating (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of BestRating as text
%        str2double(get(hObject,'String')) returns contents of BestRating as a double
user_entry = str2double(get(hObject,'string'));
if isnan(user_entry)
  errordlg('You must enter a numeric value','Bad Input','modal')
  uicontrol(hObject)
	return
end

if handles.dispOnScreen  
    handles
end

% Update handles structure
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function BestRating_CreateFcn(hObject, eventdata, handles)
% hObject    handle to BestRating (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function WorstRating_Callback(hObject, eventdata, handles)
% hObject    handle to WorstRating (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of WorstRating as text
%        str2double(get(hObject,'String')) returns contents of WorstRating as a double
user_entry = str2double(get(hObject,'string'));
if isnan(user_entry)
  errordlg('You must enter a numeric value','Bad Input','modal')
  uicontrol(hObject)
	return
end

if handles.dispOnScreen  
    handles
end

% Update handles structure
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function WorstRating_CreateFcn(hObject, eventdata, handles)
% hObject    handle to WorstRating (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in RatingTreatMissing.
function RatingTreatMissing_Callback(hObject, eventdata, handles)
% hObject    handle to RatingTreatMissing (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns RatingTreatMissing contents as cell array
%        contents{get(hObject,'Value')} returns selected item from RatingTreatMissing
%%%%%%%%%%%%%%%%%%%%%%INITIAL DATA%%%%%%%%%%%%%%%

handles.isactiveRulesToApply = 0;

handles.Rules = 0;
handles.HighRep = 2;
handles.RegRep = 0.5; 

handles.ResultData=0;

handles.AggRules = 0 ;
%%%%%%%%%%%%%%%%%%%%%%INITIAL DATA ENDS %%%%%%%%%%%%%%%

valPartialData = get(hObject, 'Value');

if ~isempty(find(valPartialData == 1)) 
    msgbox('Please choose Partial Ranking Model for Rating Data!','Error','modal');
    set(handles.listbox_ApplyRules,'Enable','off');
    set(handles.text_numIterations,'Enable','off');
    set(handles.edit_numIterations,'Enable','off');
    set(handles.text_numVoters,'Enable','off');
    set(handles.edit_numVoters,'Enable','off');
    set(handles.text_randomSeed,'Enable','off');
    set(handles.edit_randomSeed,'Enable','off');
    return
elseif ~isempty(find(valPartialData == 4)) %Replace with N
    prompt={'What value to assign to missings?'};
    name='Treating Missings';
    numlines=1;
    defaultanswer={''};
    answer=inputdlg(prompt,name,numlines,defaultanswer);
    if isempty(answer) 
       return; 
    end;
    answer=str2double(answer(1));
    if isempty(answer) || ~isfinite(answer); return; end
    lines=cellstr(get(handles.RatingTreatMissing,'String'));
    lines{4}=['Replace with ' num2str(answer)];
    handles.RatingReplaceWith=answer;
    set(handles.RatingTreatMissing,'String',lines);
    set(handles.listbox_ApplyRules,'Enable','on');
    set(handles.text_numIterations,'Enable','off')
    set(handles.edit_numIterations,'Enable','off')
    set(handles.text_numVoters,'Enable','off');
    set(handles.edit_numVoters,'Enable','off');
    set(handles.text_randomSeed,'Enable','off')
    set(handles.edit_randomSeed,'Enable','off')
elseif ~isempty(find(valPartialData == 2)) || ~isempty(find(valPartialData == 3))
    set(handles.listbox_ApplyRules,'Enable','on');
    set(handles.text_numIterations,'Enable','off')
    set(handles.edit_numIterations,'Enable','off')
    set(handles.text_numVoters,'Enable','off');
    set(handles.edit_numVoters,'Enable','off');
    set(handles.text_randomSeed,'Enable','off')
    set(handles.edit_randomSeed,'Enable','off')
else 
    set(handles.listbox_ApplyRules,'Enable','off');
    set(handles.text_numIterations,'Enable','off')
    set(handles.edit_numIterations,'Enable','off')
    set(handles.text_numVoters,'Enable','off');
    set(handles.edit_numVoters,'Enable','off');
    set(handles.text_randomSeed,'Enable','off')
    set(handles.edit_randomSeed,'Enable','off')
end 

handles.isactiveRulesToApply = 0;

if handles.dispOnScreen  
    handles
end

% Update handles structure
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function RatingTreatMissing_CreateFcn(hObject, eventdata, handles)
% hObject    handle to RatingTreatMissing (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function RatingThreshold_Callback(hObject, eventdata, handles)
% hObject    handle to RatingThreshold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of RatingThreshold as text
%        str2double(get(hObject,'String')) returns contents of RatingThreshold as a double
user_entry = str2double(get(hObject,'string'));
if isnan(user_entry)
  errordlg('You must enter a numeric value','Bad Input','modal')
  uicontrol(hObject)
	return
end

if handles.dispOnScreen  
    handles
end

% Update handles structure
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function RatingThreshold_CreateFcn(hObject, eventdata, handles)
% hObject    handle to RatingThreshold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
