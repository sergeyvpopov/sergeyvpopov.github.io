function [bsummary] = summarizeBallots(bplData)
%function [bsummary] = summarizeBallots(bplData)
%Arthur to count similar raws in matrix

bplData(find(isnan(bplData)))=0;
[ballots, dummy, counts] = unique(bplData,'rows');

for i=1:length(dummy)
    bcount(i)=sum(counts==i);
end
bsummary=[ballots,bcount'];