function [W,V,U,cV1,cV2,cW1,cW2,h,q,bp1]=IterateValueFunctionsAdj(W_old,V_old,iter);
    global theta theta0 theta1 rho s2 R BSD YSD bSD ySD beta phi;
    global pi;

% Consumer's "old" choice

U=max(kron(ones(1,BSD),W_old),V_old);
h=1-(U==V_old);

% Answers initialization
q=ones(YSD,BSD)/(1+R);
V=zeros(YSD,BSD);
W=zeros(YSD,1);
cW1=zeros(YSD,1);
cW2=zeros(YSD,1);
cV1=zeros(YSD,BSD);
cV2=zeros(YSD,BSD);
bp1=zeros(YSD,BSD);

% International borrowing market clearance using old rules
Probs=@(x) TauchenRandomValue(log(ySD),rho*log(x),s2,1);

for i=1:YSD;
    ExpCondOnY=@(k) Probs(ySD(i))*k;
    for j=1:BSD;
       q(i,j)=(1-ExpCondOnY(h(:,j)))/(1+R);
    end;
end;

% Savings decision as a best response to old rules and intl borrowing
for i=1:YSD;
    ExpCondOnY=@(k) Probs(ySD(i))*k;
    ExpU     =@(t) interp1(bSD,ExpCondOnY(U),t,'linear','extrap');
    WToMax=@(x) -(utility(ySD(i)-x,(theta1*(1-pi)*(max(x+theta0,0))^theta)-(x<0))+beta*(phi*ExpCondOnY(W_old)+(1-phi)*ExpU(0) ));
    [ex,v]=fminsearch(WToMax,-theta0+0.001);
    W(i)=-v;
    cW1(i)=ySD(i)-ex;
    cW2(i)=theta1*(1-pi)*(ex+theta0)^theta;
    expq=@(t) interp1(bSD,q',t,'linear')';
    qt=@(t) t*ExpCondOnY(expq(t));
    for j=1:BSD;
        % x(1) is export, x(2) is borrowing
       WToMax=@(x) -(utility(ySD(i)-x(1)-bSD(j)+qt(x(2)),theta1*(max(x(1)+theta0,0))^theta-(x(1)<0))+beta*ExpU(x(2)));
       [x,v]=fminsearch(WToMax,[-theta0+0.001,bSD(j)]);
       cV1(i,j)=ySD(i)-x(1)-bSD(j)+qt(x(2));
       cV2(i,j)=theta1*(x(1)+theta0)^theta;
       bp1(i,j)=x(2);
       V(i,j)=min(-v,utility(1.5*cV1(i,j),1.5*cV2(i,j))/(1-beta));
    end;
end;

% Consumer's "new" choice

if nargin==2;
    iter=1;
end;

U=max(kron(ones(1,BSD),W),V);
h=1-(U==V);

for i=1:YSD;
    ExpCondOnY=@(k) Probs(ySD(i))*k;
    for j=1:BSD;
       q(i,j)=(1-ExpCondOnY(h(:,j)))/(1+R);
    end;
end;

if iter<=1;
    U=max(kron(ones(1,BSD),W),V);
    h=1-(U==V);
else;
    disp(iter);
    save 'temp.mat';
    [W,V,U,cV1,cV2,cW1,cW2,h,q,bp1]=IterateValueFunctionsAdj(W,V,iter-1);
end;