clear;
% defining dimensionality
global BSD YSD;
BSD=150;
YSD=15;

% defining economy mechanics
global alpha kappa sigma theta theta0 theta1 rho s2 ySD R bSD pi beta phi;
R=(0.017); % intl exchange rate - Arellano's paper quarterly data 
beta=0.953; % intertemporal subst - Arellano's paper quarterly data
sigma=2; % intertemp risk aversity - Arellano's paper quarterly data
rho=0.9878; % country log-income AR coeff, regression of detrended per capita GDP 
s2=0.0258^2; % country log-income variance of AR, regression of detrended per capita GDP 
phi=1-0.282; % prob to forgive - Arellano's paper quarterly data


pi= .5;

%international trade variables
theta0=-0.0467;
theta1=0.1959;
theta=0.2082;
alpha=0.5859;
kappa=0.8447;

% defining spaces of variables

ySD=exp(linspace(-4*sqrt(s2)/sqrt(1-rho^2),4*sqrt(s2)/sqrt(1-rho^2),YSD));
% really big size of bond space:
%bSD=[linspace(-12,-1,BSD/4),linspace(-1+12/BSD,9,BSD*3/4)];
%smaller:
lendspace=linspace(-2,0,BSD/6);
borrowspace = linspace(0,2,BSD*5/6+1);
bSD = [lendspace,borrowspace(2:BSD*5/6+1)];

%initialize values functions
W0 = utility(ySD-0.01,0.01*ones(1,YSD))'./(1-beta);
V0 = kron(ones(1,BSD),utility(ySD-0.01,0.01*ones(1,YSD))'./(1-beta));
%[W,V,U,cV1,cV2,cW1,cW2,h,q,bp1]=IterateValueFunction(W0,V0,50);