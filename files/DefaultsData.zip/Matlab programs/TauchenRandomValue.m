function res=TauchenRandomValue(x,Ey,Vy,dont);
if nargin==3;
    dont=1;
end;
k=size(x,2);
midpoints=(x(1:(k-1))+x(2:k))/2;
res=[normcdf((midpoints-Ey)/sqrt(Vy)) 1];
if dont==1;
    res(2:k)=res(2:k)-res(1:(k-1));
    return;
end;
res=min(find(res>rand));
res=x(res);


