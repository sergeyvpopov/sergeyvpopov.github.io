function data=ret_data(filename);
    global alpha kappa theta theta0 theta1 rho s2 R BSD YSD bSD ySD beta phi;
    global pi;
    load(filename,'W','beta','V','pi','alpha','s2','kappa','phi','cV1','cV2','bp1','h','q','cW1','cW2','U');

eV=(1-alpha)/(alpha)*(cV1./cV2).^(1-kappa); % exchange rate in no default
eW=(1-alpha)/(alpha)*(cW1./cW2).^(1-kappa); % exchange rate in default

mV=cV2;
xV=(cV2/theta1).^(1/theta)-theta0;
tbV=xV-eV.*mV; %trade balance in no default

mW=cW2;
xW=(cW2/(theta1*(1-pi))).^(1/theta)-theta0;
tbW=xW-eW.*mW; %trade balance in default

caV=-kron(ones(1,BSD),ySD')+cV1+xV; %capital account in no default
caW=-ySD'+cW1+xW; %capital account in default

Probs=@(x) TauchenRandomValue(log(ySD),rho*log(x),s2,1);
ExpCondOnY=@(y,k) Probs(y)*k;
NextPeriodBorrow = @(b0,y0) interp2(bSD,ySD,bp1,b0,y0,'*spline'); % borrowing policy if not defaulted
ExpectedValue = @(b0,y0,variable) interp1(bSD,ExpCondOnY(y0,variable),NextPeriodBorrow(b0,y0),'*spline'); % expected value as a function of y today and b tomorrow

% Expected value in default is ExpectedValue(:,:,h.*W)/ExpectedValue(:,:,h)
% Expected value in no default is ExpectedValue(:,:,(1-h).*V)/ExpectedValue(:,:,1-h)
% Expected drop is
% g=@(b,y) (ExpectedValue(b,y,h.*kron(ones(1,BSD),eW))/ExpectedValue(b,y,h))/interp2(bSD,ySD,eV,b,y);

tb=(1-h).*tbV+h.*kron(ones(1,BSD),tbW);
ca=(1-h).*caV+h.*kron(ones(1,BSD),caW);

x=(1-h).*xV+h.*kron(ones(1,BSD),xW);
m=(1-h).*mV+h.*kron(ones(1,BSD),mW);

% Cutoff rule level
bd=@(inc) fsolve(@(bor) interp2(bSD,ySD,min(10,max(-10,V-kron(ones(1,BSD),W))),bor,inc,'linear'),bSD(10));

%consumption of home goods before and after default
c1nod=@(inc) interp2(bSD,ySD,cV1,bd(inc),inc,'*spline');
c1def=@(inc) interp2(bSD,ySD,kron(ones(1,BSD),cW1),bd(inc),inc,'*spline');
%expenditure on imported goods before and after default
c2nod=@(inc) interp2(bSD,ySD,eV.*cV2,bd(inc),inc,'*spline');
c2def=@(inc) interp2(bSD,ySD,kron(ones(1,BSD),eW.*cW2),bd(inc),inc,'*spline');

c1drop=@(inc) interp2(bSD,ySD,kron(ones(1,BSD),cW1)./cV1,bd(inc),inc,'*spline');
c2drop=@(inc) interp2(bSD,ySD,kron(ones(1,BSD),cW2)./cV2,bd(inc),inc,'*spline');
xdrop=@(inc) interp2(bSD,ySD,kron(ones(1,BSD),xW)./xV,bd(inc),inc,'*spline');

% Borrowing policy
bprime = @(b0,y0) interp2(bSD,ySD,bp1,b0,y0,'*spline');
% interest rate
qextrap = @(b0,y0) interp2(bSD,ySD,q,b0,y0);
% capital account in no default
capaccV = @(b0,y0) qextrap(bprime(b0,y0),y0).*bprime(b0,y0)-b0;
% trade balance in no default
tradebV = @(b0,y0) interp2(bSD,ySD,tbV,b0,y0);
% trade balance in default
tradebW = @(y0) interp1(ySD,tbW,y0);

dropCapInfl = @(inc) tradebV(bd(inc),inc)-capaccV(bd(inc),inc)-tradebW(inc); 
edrop=@(inc) interp2(bSD,ySD,kron(ones(1,BSD),eW)./eV,bd(inc),inc);

ys=ySD;
data=[];
for i=1:size(ys,2);
    temp=bd(ys(i));
    data=[data; [ys(i); temp; c1drop(ys(i)); c2drop(ys(i)); edrop(ys(i)); capaccV(temp,ys(i)); tradebV(temp,ys(i)); tradebW(ys(i)); 1/qextrap(temp,ys(i))-1; c1nod(ys(i)); c1def(ys(i)); c2nod(ys(i)); c2def(ys(i))]'];

end;
disp('Done!');
