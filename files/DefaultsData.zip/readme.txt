This archive contain data and estimation routines for Popov & Wiczer "Equilibrium Sovereign Default with Endogenous Exchange Rate Depreciation" paper.

	1) Data.xls contains necessary data from INDEC, European Bank and CIA factbook on Argentina; namely, time series on real quarterly per capita consumption, export, import, GDP and exchange rate.
	2) "Matlab programs" folder contains programs for estimation of the economy
		2.1) To estimate an economy, run Main.m to initialize globals (notions are the same as in the paper). Then, use IterateValueFunctionAdj.m to iterate V and W as much as you want to:
		[W,V]=IterateValueFunctionAdj(W,V,50);
		2.2) Use [W,V,U,cV1,cV2,cW1,cW2,h,q,bp1]=IterateValueFunction(W,V); to extract policy functions implied by value functions.
		2.3) Save the workspace in a .m file; benchmark.mat is the economy we use as a benchmark.
		2.4) Use ret_data.m to plot graphs from Chapter 3.
	3) "Stata Programs" contain NLLS.do to run on data from regress.dta to obtain \theta parameters.