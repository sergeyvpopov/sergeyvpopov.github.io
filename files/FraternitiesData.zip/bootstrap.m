% loading data
load('sample.mat'); 
%getting rid of low GPAs
allcum=allcum(find(allcum>2));
fraternity=fraternity(find(fraternity>2));
% creating the storage of bootstrapped values
vals=zeros(1000,12);
% points where probabilities of being a member are evaluated
k=linspace(0.05,0.95,20)';
% probabilities of being a member
mu=1-(1345/8634)*ksdensity(fraternity,quantile(allcum,k))./ksdensity(allcum,quantile(allcum,k));
% function to minimize
g=@(u) estim3(u,k,mu,10);    
% minimizing
q=fminsearch(g,log((0.5840-0.5)/(1-0.5840)));
% first row is a list of estimated parameters
vals(1,:)=estim4(q,k,mu,10)';
%repeating 999 times
for i=2:1000;
    fraternity1=resample(fraternity);
    allcum1=resample(allcum);
    mu=1-(1345/8634)*ksdensity(fraternity1,quantile(allcum1,k))./ksdensity(allcum1,quantile(allcum1,k));
    g=@(u) estim3(u,k,mu,10);    
    q=fminsearch(g,log((0.5840-0.5)/(1-0.5840)));
    vals(i,:)=estim4(q,k,mu,10)';
    disp(i);
end;
