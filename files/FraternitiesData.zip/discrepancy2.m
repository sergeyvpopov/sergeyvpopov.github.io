function di=discrepancy2(params,report); %This function is used to calculate the lasso-type penalty (see page 20 of the paper for explanation)
% =============== Initiation ===============
a1=params(1); %The intercept of the first line segment, for \thetas in [0,0.5]
b1=-params(2); % Slope of the first line segment, for \thetas in [0,0.5]
b2=-params(2)-params(3); % Slope of the second line segment, for \thetas in [0.5,k]
b3=b2-params(4); % Slope of the third line segment, for \thetas in [k,1]
k=params(5); % \theta where fraternity's choice and students' choice intersect
a2=params(1)-(b1-b2)/2; %The intercept of second line segment, for \thetas in [0.5,k]
a3=a2-(b2-b3)*k; %The intercept of third line segment, for \thetas in [k,1]

% ========= Calculating wages imposed by lines positions ============
% To use symbolical integration commands, one has to define
% syms theta
% and apply eval() to the result.

% Mass of students in fraternity with low signal, formula obtained by using
% command int((1-(a1-b1*theta))*(1-2*theta),theta,0,1/2);
p_c_l=1/24*b1+1/4-1/4*a1;
% Output of students in fraternity with low signal, formula obtained by
% using command int(theta*(1-(a1-b1*theta))*(1-2*theta),theta,0,1/2);
e_c_l=1/96*b1+1/24-1/24*a1;
% Mass of students outside of fraternity with low signal, equivalent to
% using command int((1-2*theta),theta,0,a0)+int((a1-b1*theta)*(1-2*theta),theta,a0,1/2);
p_noc_l=1/4-p_c_l;
% Output of students outside of fraternity with low signal, equivalent to
% using command int(theta*(1-2*theta),theta,0,a0)+int(theta*(a1-b1*theta)*(1-2*theta),theta,a0,1/2);
e_noc_l=1/24-e_c_l;

% Mass of students in fraternity with high signal, formula obtained by using
% command int(2*theta-1)*(1-(a3-b3*theta)),theta,k,1)+int((2*theta-1)*(1-(a2-b2*theta)),theta,1/2,k);
p_c_h=2/3*b3*(1-k^3)+1/2*(-b3+2-2*a3)*(1-k^2)-1/2+a3*(1-k)+2/3*b2*(k^3-1/8)+1/2*(-b2+2-2*a2)*(k^2-1/4)+a2*(k-1/2);
% Output of students in fraternity with high signal, formula obtained by using
% command int(theta*(2*theta-1)*(1-(a3-b3*theta)),theta,k,1)+int(theta*(2*theta-1)*(1-(a2-b2*theta)),theta,1/2,k);
e_c_h=1/2*b3*(1-k^4)+1/3*(-b3+2-2*a3)*(1-k^3)+1/2*(-1+a3)*(1-k^2)+1/2*b2*(k^4-1/16)+1/3*(-b2+2-2*a2)*(k^3-1/8)+1/2*(-1+a2)*(k^2-1/4);
% Mass of students outside of fraternity with high signal, equivalent to using command
% int((2*theta-1)*(a3-b3*theta),theta,k,1)+int((2*theta-1)*(a2-b2*theta),theta,1/2,k);
p_noc_h=1/4-p_c_h;
% Output of students outside of fraternity with high signal, equivalent to using command
% int(theta*(2*theta-1)*(a3-b3*theta),theta,k,1)+int(theta*(2*theta-1)*(a2-b2*theta),theta,1/2,k);
e_noc_h=5/24-e_c_h;

% Mass of students in fraternity with medium signal, formula obtained by using command
% int((2-2*theta)*(1-(a3-b3*theta)),theta,k,1)+int((2-2*theta)*(1-(a2-b2*theta)),theta,1/2,k)+int((1-(a1-b1*theta))*(2*theta),theta,a0,1/2);
p_c_m=-2/3*b3*(1-k^3)+1/2*(2*b3-2+2*a3)*(1-k^2)+5/4-2*a3*(1-k)-2/3*b2*(k^3-1/8)+1/2*(2*b2-2+2*a2)*(k^2-1/4)-2*a2*(k-1/2)+1/12*b1-1/4*a1;
% Output of students in fraternity with medium signal, formula obtained by using command
% int(theta*(2-2*theta)*(1-(a3-b3*theta)),theta,k,1)+int(theta*(2-2*theta)*(1-(a2-b2*theta)),theta,1/2,k)+int(theta*(1-(a1-b1*theta))*(2*theta),theta,a0,1/2))
e_c_m=-1/2*b3*(1-k^4)+1/3*(2*b3-2+2*a3)*(1-k^3)+1/2*(2-2*a3)*(1-k^2)-1/2*b2*(k^4-1/16)+1/3*(2*b2-2+2*a2)*(k^3-1/8)+1/2*(2-2*a2)*(k^2-1/4)+1/32*b1+1/12-1/12*a1;
% Mass of students outside of fraternity with medium signal, equivalent to using command
% int((2-2*theta)*(a3-b3*theta),theta,k,1)+int((2-2*theta)*(a2-b2*theta),theta,1/2,k)+int(1*(2*theta),theta,0,a0)+int(((a1-b1*theta))*(2*theta),theta,a0,1/2);
p_noc_m=1/2-p_c_m;
% Output of students outside of fraternity with medium signal, equivalent to using command
% int(theta*(2-2*theta)*(a3-b3*theta),theta,k,1)+int(theta*(2-2*theta)*(a2-b2*theta),theta,1/2,k)+int(theta*1*(2*theta),theta,0,a0)+int(theta*((a1-b1*theta))*(2*theta),theta,a0,1/2);
e_noc_m=1/4-e_c_m;

% Wages in the group are outputs of the groups divided by the sizes of the groups
w_c_l=e_c_l/p_c_l;
w_noc_l=e_noc_l/p_noc_l;

w_noc_h=e_noc_h/p_noc_h;
w_c_h=e_c_h/p_c_h;

w_c_m=e_c_m/p_c_m;
w_noc_m=e_noc_m/p_noc_m;

% =============== Reporting ===============

% Default reporting

% The penalty for not being in a equilibrium (see page 20 of the paper for
% explanation) is a function of this difference
di=(w_c_m-w_c_l)*b2-b1*(w_c_h-w_c_m);

% One type of repoting results
if report==1;
    % Parameter of student's utility function
    n=2*(w_c_h-w_noc_h-w_c_m+w_noc_m)/b3;
    % Joining cost parameter
    c=n*(a3-b3)+w_c_h-w_noc_h;
    % Printing values
    disp([n c]);
    disp([b1/(w_c_m-w_c_l) b2/(w_c_h-w_c_m)]/2);
end;
% Another type of repoting results
if report==2;
    % Parameter of student's utility function
    n=2*(w_c_h-w_noc_h-w_c_m+w_noc_m)/b3;
    % Joining cost parameter
    c=n*(a3-b3)+w_c_h-w_noc_h;
    % Reporting utility function parameters, two ways of estimating the
    % fraternity utility function parameter, and capacity estimate
    di=[n;c;b1/((w_c_m-w_c_l)*2);b2/((w_c_h-w_c_m)*2);p_c_l+p_c_m+p_c_h];
end;