function est=estim3(k1,t,mu,g); %This function estimates the minimum SSE for given position of interception point and reports the penalized SSE

% =============== Interception point ==============
q=0.5+0.5*exp(k1)/(1+exp(k1));

% looking for a starting point
coefs=[ones(size(mu,1),1) t (t-0.5).*(t>0.5) (t-q).*(t>q)]\mu;

% ========= Estimation =============
% defining the penalty function
discr=@(s) discrepancy2([s;q],0)^2;
if g==0;
    discr=@(s) 0;
end;
% defining the SSE function
mse=@(s) sum(([ones(size(mu,1),1) t (t-0.5).*(t>0.5) (t-q).*(t>q)]*s-mu).^2);
% minimizing the sum of those weighing by parameter g
[coefs,est]=fminsearch(@(s) mse(s)+g*discr(s),coefs);

% ========= Results =============
params=[coefs(1);0;0;-coefs(2);-(coefs(2)+coefs(3));-(coefs(2)+coefs(3)+coefs(4));q];
params(2)=params(1)-params(4)/2+params(5)/2;
params(3)=params(2)-params(5)*q+params(6)*q;
%disp(mse(coefs));
%disp(discr(coefs));
%disp(params);


