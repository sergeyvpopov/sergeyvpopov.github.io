function nums=resample(original);
N=size(original,1);
nums=original(floor(rand(N,1)*N)+1,:);